package com.qihoo.appstore.data.plugin.info;

import android.text.TextUtils;

import com.qihoo.appstore.data.plugin.constant.DownloadConsts;
import com.qihoo.appstore.data.plugin.constant.Consts;
import com.qihoo.utils.ContextUtils;
import com.qihoo.utils.FormatUtils;
import com.qihoo.utils.LogUtils;
import com.qihoo.utils.Md5Utils;
import com.qihoo.utils.RandomUtils;
import com.qihoo.utils.TimeUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

/*
 1: canUseTFWModel 拿到上层处理
  3: android.os.FileUtils.setPermissions(state.mSavePath, 0644, -1, -1);
 * */

public class DownloadResInfo {

    private final String TAG = "DownloadResInfo";

    public int mStatus = DownloadConsts.Status.STATUS_NOT_START;

    public boolean reDownload;

    public int downloadEngineType;

    public boolean useHttps;

    public String sequenceId; // 第几个下载任务，服务器端排重使用。
    public volatile int mTaskID = -1;
    public int mDownloadTimes;
    public int mErrorCode;
    public boolean canUseDataNet; // 用户确认可以使用数据网络。
    public int mControl;

    public String downloadUrl;
    public String httpsDownloadUrl;
    public String p2pDownloadUrl;
    public String desDownloadUrl;// 免流量
    public String diffUrl;

    public String fileMd5;
    public String signMd5;
    public long mResSize;
    public String savePath; // 下载下来文件的路径

    public long mCurrentBytes;
    public long mTotalBytes;
    public long mP2PDownloadLen;
    public transient long mPreviousBytes;

    public int mNumFailed;
    public int mRedirectTimes;
    public int mRetryTimes;
    public int mRetryAfter;
    public int mFuzz;

    public int priority;

    public long mLastMod; // Last-Modified

    public int updateProgressNum;

    public boolean usingTFWModel = false;

    public String mUserAgent;
    public String mETag;
    public String mMimeType; // Content-Type
    public boolean isSupportSplit;

    private volatile long lastUpdateProgressTime;
    private volatile long lastDownloadBytes;
    public double mPreFinalSpeed;
    public double mFinalSpeed;
    public String mSpeedText;
    public final LinkedList<Double> mHistorySpeeds = new LinkedList<>();

    public volatile long startDownloadTime;

    public String id;
    public int resType;

    // 防止 mSubmittedTask.isDone() 与 finally 块之间的竞态窗口导致两个下载任务并发运行
    public volatile boolean isDownloadRunning = false;

    //本地内存，不用写进数据库中,也不用序列化
    public String p2pStrategyUrl;//视频云p2p代理下载地址
    public int currentDownloadBusiness = DownloadConsts.DownloadBusiness.INIT;//1,默认，2,云路由p2p
    public boolean isCdnUrl;//下载地址是否为cdn下载地址
    public String mNetCode;

    public long showSize;

    public DownloadResInfo() {
        mFuzz = RandomUtils.getRandomInt(1001);
    }

    public String getRealDownloadUrl() {
        String realDownloadUrl = downloadUrl;
        if (!TextUtils.isEmpty(p2pDownloadUrl)) {
            realDownloadUrl = p2pDownloadUrl;
        }
        if (!TextUtils.isEmpty(diffUrl)) {
            realDownloadUrl = diffUrl;
        }

        if (!TextUtils.isEmpty(realDownloadUrl) && !realDownloadUrl.contains("?") && LogUtils.isDebug()) {
            realDownloadUrl += "?debug=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
        if (TextUtils.isEmpty(realDownloadUrl)) {
            realDownloadUrl = "";
        }
        return realDownloadUrl;
    }

    public void setRealDownloadUrl(String newUrl) {
        if (!TextUtils.isEmpty(diffUrl)) {
            diffUrl = newUrl;
        } else {
            downloadUrl = newUrl;
        }
    }

    public int syncGetStatus() {
        synchronized (this) {
            return mStatus;
        }
    }

    public void syncSetStatus(int status) {
        synchronized (this) {
            mStatus = status;
        }
    }

    public int syncGetControl() {
        synchronized (this) {
            return mControl;
        }
    }

    public void syncSetControl(int control) {
        synchronized (this) {
            mControl = control;
        }
    }

    // 计算下载速度
    public void updateDownloadSpeed(long currentBytes, boolean phoneCalling2G) {
        long currentTime, lastTime, lastBytes;
        if (mStatus != DownloadConsts.Status.STATUS_RUNNING || phoneCalling2G) {
            mSpeedText = "0.00/s";
        } else {
            currentTime = System.currentTimeMillis();
            mPreFinalSpeed = Math.max(1.0, mFinalSpeed);
            if (lastUpdateProgressTime >= currentTime) {
                lastUpdateProgressTime = currentTime - 1000;
            }

            lastTime = lastUpdateProgressTime;

            if (lastDownloadBytes > currentBytes) {
                lastDownloadBytes = currentBytes;
            }

            lastBytes = lastDownloadBytes;

            long timeInterval = currentTime - lastTime;
            long bytesDifference = currentBytes - lastBytes;

            double speed = (double) bytesDifference / timeInterval * 1000;
            mFinalSpeed = getAverageSpeed(speed);

            mSpeedText = FormatUtils.formatSizeHighAccury(
                    ContextUtils.getHostAppContext(), (long) mFinalSpeed)
                    + "/s";

            lastUpdateProgressTime = currentTime;
            lastDownloadBytes = currentBytes;
        }
    }

    // 使用近5次的速度平均值进行速度平滑处理，防止速度显示波动过大
    public synchronized double getAverageSpeed(double speed) {
        // 有0进来，影响准确度
        if (speed > 0 || mHistorySpeeds.size() > 0) {
            mHistorySpeeds.addFirst(speed);
        }

        if (mHistorySpeeds.size() > 5) {
            mHistorySpeeds.removeLast();
        }

        double total = 0;
        for (Double s : mHistorySpeeds) {
            total += s;
        }

        return total / mHistorySpeeds.size();
    }

    private static long _order = 0;
    private static long _lastStartDayTime = 0;

    private long getDownloadOrder() {
        if (_lastStartDayTime == 0) {
            _lastStartDayTime = TimeUtils.todayStartTime();
        }

        long todayStartTime = TimeUtils.todayStartTime();
        if (todayStartTime != _lastStartDayTime) {
            _order = 0;
            _lastStartDayTime = TimeUtils.todayStartTime();
        }

        return ++_order;
    }

    public String getSequenceId(boolean onlyRead) {//20120201—010202_次序_8位(md5(base64(url+次数)))_8位md5(resmd5+次数)
        if (TextUtils.isEmpty(sequenceId)) {
            LogUtils.d(TAG, "getSequenceId() " + sequenceId);
            long order = getDownloadOrder();
            String md5A = Md5Utils.md5(getRealDownloadUrl() + "" + order);
            if (!TextUtils.isEmpty(md5A) && md5A.length() > 8) {
                md5A = md5A.substring(0, 8);
            } else {
                md5A = "aaaaaaaa";
            }
            String md5B = Md5Utils.md5(fileMd5 + "" + order);
            if (!TextUtils.isEmpty(md5B) && md5B.length() > 8) {
                md5B = md5B.substring(0, 8);
            } else {
                md5B = "bbbbbbbb";
            }

            Date currentTime = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
            String dateString = formatter.format(currentTime);

            sequenceId = String.format("%s_%d_%d_%s_%s", dateString, order, android.os.Process.myPid(), md5A, md5B);
        }
        LogUtils.d(TAG, "getSequenceId() " + sequenceId);
        LogUtils.safeCheck(!TextUtils.isEmpty(sequenceId));
        return sequenceId;
    }

    public boolean isPluginTask() {
        if (TextUtils.isEmpty(id)) {
            return false;
        }
        return id.endsWith(Consts.Plguin.PLUGIN_ID_SUFFIC);
    }

}