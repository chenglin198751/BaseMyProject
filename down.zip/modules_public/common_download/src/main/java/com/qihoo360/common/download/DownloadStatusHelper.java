package com.qihoo360.common.download;

import android.content.Context;
import android.graphics.Color;
import android.icu.text.IDNA;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.qihoo.appstore.data.plugin.StatFieldConst;
import com.qihoo.appstore.data.plugin.constant.Consts;
import com.qihoo.appstore.data.plugin.constant.DownloadConsts;
import com.qihoo.appstore.widget.bar.DownloadProgressBar;
import com.qihoo.appstore.widget.button.CircularProgressButton;
import com.qihoo.appstore.widget.button.HorizontalProgressButton;

import com.qihoo.common.download.R;
import com.qihoo.download.DownloadObjs;
import com.qihoo.manage.ClientInfoManager;
import com.qihoo.manage.DownloadManager;
import com.qihoo.manage.DownloadStateJudge;
import com.qihoo.manage.InstallManager;
import com.qihoo.manage.LocalAppManager;
import com.qihoo.product.ApkResInfo;
import com.qihoo.product.BaseResInfo;
import com.qihoo.product.QHDownloadResInfo;
import com.qihoo.product.RecommendApkResInfo;
import com.qihoo.product.SearchApkResInfo;
import com.qihoo.product.theme.SkinHelper;
import com.qihoo.utils.ApkUtils;
import com.qihoo.utils.ContextUtils;
import com.qihoo.utils.DeviceUtils;
import com.qihoo.utils.FileUtils;
import com.qihoo.utils.FormatUtils;
import com.qihoo.utils.LogUtils;
import com.qihoo.utils.ReflectUtils;
import com.qihoo.utils.SDCardUtils;
import com.qihoo.utils.SafetyFieldUtils;
import com.qihoo360.base.viewholder.BaseViewHolder;
import com.qihoo360.common.MicroAppConfig;
import com.qihoo360.common.consts.RankData;
import com.qihoo360.common.helper.StatHelper;
import com.qihoo360.skin.helper.AppSkinHelper;

import java.util.Map;

import static com.qihoo360.common.download.State.IDLE;

public class DownloadStatusHelper {

    private static final String TAG = "DownloadStatusHelper";
    public static final int TYPE_NO_ANIMATION = 0;
    public static final int TYPE_GENTLE = 1;
    public static int progressBarResId = -1;

    public static HorizontalProgressButton.State getViewState(ApkResInfo apkResInfo) {
        HorizontalProgressButton.State viewState = HorizontalProgressButton.State.IDLE;
        if (apkResInfo != null) {
            State state = DownloadStatusHelper.getAppState(apkResInfo.resPackageName, apkResInfo.versionCode, false);
            if (state != null) {
                switch (state) {
                    case COMPLETE:
                        viewState = HorizontalProgressButton.State.COMPLETE;
                        break;
                    case PROGRESSING:
                        viewState = HorizontalProgressButton.State.PROGRESSING;
                        break;
                    case INSTALLING:
                        viewState = HorizontalProgressButton.State.INSTALLING;
                        break;
                    case WAITWIFI:
                        viewState = HorizontalProgressButton.State.WAITWIFI;
                        break;
                    case PROCESS:
                        viewState = HorizontalProgressButton.State.PROCESS;
                        break;
                    case PAUSED:
                        viewState = HorizontalProgressButton.State.PAUSED;
                        break;
                    case MERGE:
                        viewState = HorizontalProgressButton.State.MERGE;
                        break;
                    case ERROR:
                        viewState = HorizontalProgressButton.State.ERROR;
                        break;
                    case OPEN:
                        //因为之前matchVersion为false，确认应用已安装后这里判断是否需要升级
                        if (State.UPDATED == DownloadStatusHelper.getAppState(apkResInfo.resPackageName, apkResInfo.versionCode, true)) {
                            viewState = HorizontalProgressButton.State.UPDATED;
                        } else {
                            viewState = HorizontalProgressButton.State.OPEN;
                        }
                        break;
                    case IDLE:
                        viewState = HorizontalProgressButton.State.IDLE;
                        break;
                    case UPDATED:
                        viewState = HorizontalProgressButton.State.UPDATED;
                        break;
                    case WAITING:
                        viewState = HorizontalProgressButton.State.WAITING;
                        break;
                    case INSTALLED:
                        viewState = HorizontalProgressButton.State.OPEN;
                        break;
                }
            }
            //只要该应用已经安装，并且是鸿蒙应用，状态就是OPEN
            if (ApkUtils.isHarmonyApp(apkResInfo.resPackageName)) {
                viewState = HorizontalProgressButton.State.OPEN;
            }
        }
        return viewState;
    }

    public static boolean getProgressBarVisibility(QHDownloadResInfo downInfo) {
        if (downInfo != null) {
            switch (downInfo.mStatus) {
                case DownloadConsts.Status.STATUS_RUNNING:
                case DownloadConsts.Status.STATUS_PAUSING:
                case DownloadConsts.Status.STATUS_PAUSED:
                case DownloadConsts.Status.STATUS_PENDING:
                case DownloadConsts.Status.STATUS_CONTINUE_PENDING:
                    return true;
                default:
                    return DownloadConsts.isDownloadError(downInfo.mStatus);
            }
        }
        return false;
    }

    public static int getProgress(QHDownloadResInfo downInfo) {
        if (downInfo != null && downInfo.mTotalBytes > 0) {
            return Math.min(100, (int) (downInfo.mCurrentBytes * 100.0f / downInfo.mTotalBytes));
        } else if (downInfo != null && downInfo.mTotalBytes == 0) {
            return 100;
        }
        return 0;
    }

    /**
     * @param mContext
     * @param downloadProgressBars DownloadProgressBar和Holder的map， Holder可以是BaseViewHolder 也可以是RecyclerViewAdapter.BaseRecyclerViewHolder
     * @param info
     */
    public static void onProgressStatus(Context mContext, Map<DownloadProgressBar, Object> downloadProgressBars, QHDownloadResInfo info) {
        onProgressStatus(mContext, downloadProgressBars, info, 0);
    }

    public static void onProgressStatus(Context mContext, Map<DownloadProgressBar, Object> downloadProgressBars, QHDownloadResInfo info, int themeColor) {
        onProgressStatus(mContext, R.id.common_list_desc, downloadProgressBars, info, themeColor);
    }

    public static void onProgressStatus(Context mContext, int viewId, Map<DownloadProgressBar, Object> downloadProgressBars, QHDownloadResInfo info, int themeColor) {
        for (DownloadProgressBar progressBar : downloadProgressBars.keySet()) {
            //将progressbar放在一个viewgroup里，以便此处统一通过progressbar的parent进行显示控制
            Object holder = downloadProgressBars.get(progressBar);
            if (holder != null) {
                if (holder instanceof BaseViewHolder) {
                    setProgress(mContext, viewId, info, progressBar, (ViewGroup) progressBar.getParent(), (BaseViewHolder) downloadProgressBars.get(progressBar), true, themeColor);

                } else if (TextUtils.equals(holder.getClass().getName(), "com.qihoo.appstore.widget.adapter.RecyclerViewAdapter.BaseRecyclerViewHolder")) {
                    setProgress(mContext, info, progressBar, (ViewGroup) progressBar.getParent(),
                             downloadProgressBars.get(progressBar), true);
                }
            }
        }
    }


    /**
     * 此方法为公用方法请不要随意改动
     */
    public static void setProgress(Context mContext, QHDownloadResInfo info, DownloadProgressBar progressBar, View container, BaseViewHolder holder, boolean smooth) {
        setProgress(mContext, R.id.common_list_desc, info, progressBar, container, holder, smooth);
    }

    public static void setProgress(Context mContext, QHDownloadResInfo info, DownloadProgressBar progressBar, View container, BaseViewHolder holder, boolean smooth, int themeColor) {
        setProgress(mContext, R.id.common_list_desc, info, progressBar, container, holder, smooth);
    }

    /**
     * 首页专用
     */
    public static void setProgress(Context mContext, int viewId, QHDownloadResInfo info, DownloadProgressBar progressBar, View container, BaseViewHolder holder, boolean smooth) {
        setProgress(mContext, viewId, info, progressBar, container, holder, smooth, 0);
    }

    public static void setProgress(Context mContext, int viewId, QHDownloadResInfo info, DownloadProgressBar progressBar, View container, BaseViewHolder holder, boolean smooth, int themeColor) {
        boolean visible = DownloadStatusHelper.getProgressBarVisibility(info);
        if (visible) {
            container.setVisibility(View.VISIBLE);
            progressBar.setStatus(info.mStatus == DownloadConsts.Status.STATUS_RUNNING);
            int progress = DownloadStatusHelper.getProgress(info);
            if (smooth) {
                progressBar.setProgressBySmoothly(progress);
            } else {
                progressBar.setProgressDirectly(progress);
            }
            setProgressColor(mContext, info, progressBar);
            View leftView = holder.getView(R.id.download_left_size_text);
            View rightView = holder.getView(R.id.download_right_speed_text);
            if (leftView != null && rightView != null && leftView instanceof TextView && rightView instanceof TextView) {
                DownloadStatusHelper.setDownloadStatus(mContext, (TextView) leftView, (TextView) rightView, info, themeColor);
            }
            setResidueTimeAndTips(mContext, info, holder.getView(R.id.common_list_desc),
                    (TextView) holder.getView(R.id.download_left_tips_text),
                    (TextView) holder.getView(R.id.download_right_action_text), holder.getView(R.id.common_content_yellow_bar));
        } else {
            container.setVisibility(View.INVISIBLE);
            progressBar.setStatus(false);
        }
    }

    public static void setProgress(Context mContext, QHDownloadResInfo info, DownloadProgressBar progressBar, View container, View root, boolean smooth) {
        boolean visible = DownloadStatusHelper.getProgressBarVisibility(info);
        if (visible) {
            container.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setStatus(info.mStatus == DownloadConsts.Status.STATUS_RUNNING);
            int progress = DownloadStatusHelper.getProgress(info);
            if (smooth) {
                progressBar.setProgressBySmoothly(progress);
            } else {
                progressBar.setProgressDirectly(progress);
            }
            setProgressColor(mContext, info, progressBar);
            View leftView = root.findViewById(R.id.download_left_size_text);
            View rightView = root.findViewById(R.id.download_right_speed_text);
            if (leftView != null && rightView != null && leftView instanceof TextView && rightView instanceof TextView) {
                DownloadStatusHelper.setDownloadStatus(mContext, (TextView) leftView, (TextView) rightView, info, 0);
            }
        } else {
            container.setVisibility(View.INVISIBLE);
            progressBar.setStatus(false);
        }
    }

    public static void setProgressColor(Context mContext, QHDownloadResInfo info, DownloadProgressBar progressBar) {
        if (info != null && progressBar != null) {
            if (info.mStatus == DownloadConsts.Status.STATUS_PAUSED) {
                progressBar.setProgressColor(R.drawable.progress_horizontal_yellow_color);
            } else if (DownloadConsts.isDownloadError(info.mStatus)) {
                progressBar.setProgressColor(R.drawable.progress_horizontal_grey);
            } else {
                if (progressBarResId == -1) {
                    progressBarResId = AppSkinHelper.getAttributeResourceId(mContext, R.attr.themeProgressbarHorizontalDrawable, R.drawable.progress_horizontal_green);
                }
                progressBar.setProgressColor(progressBarResId);
            }
        }
    }

    public static void setProgress(Context mContext, QHDownloadResInfo info, View container, boolean smooth) {
        boolean visible = DownloadStatusHelper.getProgressBarVisibility(info);
        DownloadProgressBar progressBar = ((DownloadProgressBar) container.findViewById(R.id.download_progress));
        if (visible) {
            container.setVisibility(View.VISIBLE);
            progressBar.setStatus(info.mStatus == DownloadConsts.Status.STATUS_RUNNING);
            int progress = DownloadStatusHelper.getProgress(info);
            if (smooth) {
                progressBar.setProgressBySmoothly(progress);
            } else {
                progressBar.setProgressDirectly(progress);
            }
            setProgressColor(mContext, info, progressBar);
            View leftView = container.findViewById(R.id.download_left_size_text);
            View rightView = container.findViewById(R.id.download_right_speed_text);
            if (leftView != null && rightView != null && leftView instanceof TextView && rightView instanceof TextView) {
                DownloadStatusHelper.setDownloadStatus(mContext, (TextView) leftView, (TextView) rightView, info);
            }
        } else {
            container.setVisibility(View.INVISIBLE);
            progressBar.setStatus(false);
        }
    }

    public static void setResidueTimeAndTips(Context mContext, final QHDownloadResInfo info,
                                             View desc, final TextView leftTips, final TextView rightAction, View contentBar) {
        boolean visible = DownloadStatusHelper.getProgressBarVisibility(info);
        //info.getShowTime()判断不合理且没有必要，有!getContentBarVisibility(holder)限制即可，
        // 需回归内容外显下载剩余时间是否显示正常
        if (visible && leftTips != null && rightAction != null && info != null /*&& info.getShowTime()*/) {
            if (info.mStatus == DownloadConsts.Status.STATUS_RUNNING) {
                double mFinalSpeed = info.mFinalSpeed;
                long residueBytes = info.mTotalBytes - info.mCurrentBytes;
                if (mFinalSpeed != 0 && !Double.isNaN(mFinalSpeed) && !getContentBarVisibility(contentBar)) {
                    int residueTimeBySecond = Math.max(1, (int) (residueBytes / mFinalSpeed));
                    if (residueTimeBySecond < 20 * 60 || leftTips.getVisibility() == View.VISIBLE) {//小于20分钟
                        leftTips.setVisibility(View.VISIBLE);
                        leftTips.setText(mContext.getResources().getString(R.string.download_list_body_tips2, FormatUtils.formatTimeByChinese(residueTimeBySecond)));
                        leftTips.setTextColor(SkinHelper.getAttributeColor(mContext, R.attr.themeListItemDescColor, Color.BLACK));
                        rightAction.setVisibility(View.INVISIBLE);
                        if (desc != null) {
                            desc.setVisibility(View.GONE);
                        }
                        return;
                    } else {
                        if (desc != null) {
                            desc.setVisibility(View.VISIBLE);
                        }
                    }
                }
            } else if (info.mStatus == DownloadConsts.Status.STATUS_PAUSED || info.mStatus == DownloadConsts.Status.STATUS_PAUSING) {
                double mFinalSpeed = info.mFinalSpeed;
                long residueBytes = info.mTotalBytes - info.mCurrentBytes;
                if (mFinalSpeed != 0 && !Double.isNaN(mFinalSpeed) && !getContentBarVisibility(contentBar)) {
                    int residueTimeBySecond = Math.max(1, (int) (residueBytes / mFinalSpeed));
                    if (residueTimeBySecond < 2 * 60) {
                        leftTips.setVisibility(View.VISIBLE);
                        leftTips.setText(mContext.getResources().getString(R.string.download_list_body_tips1, FormatUtils.formatTimeByChinese(residueTimeBySecond)));
                        leftTips.setTextColor(Color.parseColor("#fffb700b"));
                        rightAction.setVisibility(View.INVISIBLE);
                        if (desc != null) {
                            desc.setVisibility(View.GONE);
                        }
                        return;
                    }
                }
                if (info.mFinalSpeed > 0 && info.mFinalSpeed < 500 * 1024 && info.getPausedByUser() <= 0 && !getContentBarVisibility(contentBar)) {
                    if (info.getPausedByUser() == -1) {

                        leftTips.setVisibility(View.VISIBLE);
                        leftTips.setText(R.string.download_list_body_tips);
                        leftTips.setTextColor(Color.parseColor("#fffb700b"));
                        rightAction.setVisibility(View.VISIBLE);
                        rightAction.setTextColor(AppSkinHelper.getAttributeColor(mContext, R.attr.themeButtonColorValue, Color.parseColor("#8d8d8d")));
                        rightAction.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                info.setPauseddByUser(0);
                                rightAction.setVisibility(View.INVISIBLE);
                                leftTips.setText(R.string.download_list_body_tips3);
                                StatHelper.onEvent("downoptimize", "oneswitch");
                            }
                        });
                    } else if (info.getPausedByUser() == 0) {
                        leftTips.setText(R.string.download_list_body_tips3);
                        leftTips.setVisibility(View.VISIBLE);
                    }
                    if (desc != null) {
                        desc.setVisibility(View.GONE);
                    }
                    return;
                }

                if (desc != null) {
                    desc.setVisibility(!getContentBarVisibility(contentBar) ? View.VISIBLE : View.INVISIBLE);
                }
            } else if (info.mStatus == DownloadConsts.Status.STATUS_PENDING) {
                if (desc != null) {
                    desc.setVisibility(View.GONE);
                }
            }
        }
        if (leftTips != null) {
            leftTips.setVisibility(View.GONE);
        }
        if (rightAction != null) {
            rightAction.setVisibility(View.GONE);
        }
    }

    private static boolean getContentBarVisibility(View contentBar) {
        boolean visible = contentBar != null && View.VISIBLE == contentBar.getVisibility();
        return visible;
    }

    public static void setProgress(Context mContext, QHDownloadResInfo info, DownloadProgressBar progressBar,
                                   View container, Object holder, boolean smooth) {
        if (DownloadStatusHelper.getProgressBarVisibility(info)) {
            container.setVisibility(View.VISIBLE);
            progressBar.setStatus(info.mStatus == DownloadConsts.Status.STATUS_RUNNING);
            int progress = DownloadStatusHelper.getProgress(info);
            if (smooth) {
                progressBar.setProgressBySmoothly(progress);
            } else {
                progressBar.setProgressDirectly(progress);
            }
            setProgressColor(mContext, info, progressBar);

            View leftView = (View) ReflectUtils.invokeMethod(holder, "getView", new Class[]{int.class}, R.id.download_left_size_text);
            View rightView = (View) ReflectUtils.invokeMethod(holder, "getView", new Class[]{int.class}, R.id.download_right_speed_text);
            if (leftView != null && rightView != null && leftView instanceof TextView && rightView instanceof TextView) {
                DownloadStatusHelper.setDownloadStatus(mContext, (TextView) leftView, (TextView) rightView, info);
            }
        } else {
            container.setVisibility(View.INVISIBLE);
            progressBar.setStatus(false);
        }
    }

    public static void setDownloadStatus(Context context, TextView leftView, TextView rightView, QHDownloadResInfo downInfo) {
        setDownloadStatus(context, leftView, rightView, downInfo, 0);
    }

    public static void setDownloadStatus(Context context, TextView leftView, TextView rightView, QHDownloadResInfo downInfo, int themeColor) {
        if (downInfo != null) {
            if (downInfo.mTotalBytes > 0) {
                StringBuilder sb = new StringBuilder();
                sb.append(FormatUtils.formatSize(downInfo.mCurrentBytes));
                if (DeviceUtils.getScreenWidth(ContextUtils
                        .getPluginAppContext()) > 480) {// 当屏幕分辨率小于等于480时，不显示总大小
                    sb.append("/");
                    sb.append(FormatUtils.formatSize(downInfo.mTotalBytes));
                }
                leftView.setText(sb.toString());
            }
            int color = SkinHelper.getAttributeColor(context, R.attr.themeListItemDescColor, "#15c0b3");
            if (downInfo.mStatus == DownloadConsts.Status.STATUS_RUNNING) {
                color = SkinHelper.getAttributeColor(context, R.attr.themeButtonColorValue, "#15c0b3");
                color = themeColor != 0 ? themeColor : color;
            }
            rightView.setTextColor(color);
            if (downInfo.mStatus == DownloadConsts.Status.STATUS_RUNNING) {
                rightView.setText(downInfo.mSpeedText);
            } else if (downInfo.mStatus == DownloadConsts.Status.STATUS_PAUSING) {
                rightView.setText(context.getResources().getString(
                        R.string.download_btn_text_pausing));
            } else if (downInfo.mStatus == DownloadConsts.Status.STATUS_PAUSED) {
//                rightView.setText(context.getResources().getString(
//                        R.string.download_state_psused));
                if (downInfo.getPausedByUser() == 0) {
                    rightView.setText(context.getResources().getString(
                            R.string.download_btn_text_pending));
                } else {
                    rightView.setText(context.getResources().getString(
                            R.string.download_state_psused));
                }
            } else if (downInfo.mStatus == DownloadConsts.Status.STATUS_PENDING || downInfo.mStatus == DownloadConsts.Status.STATUS_CONTINUE_PENDING) {
                rightView.setText(ContextUtils.getPluginAppContext()
                        .getString(R.string.download_btn_text_pending));
            } else if (DownloadConsts.isDownloadError(downInfo.mStatus)) {
                rightView.setText(DownloadStatusHelper.getDownloadErrInfo(ContextUtils.getPluginAppContext(), downInfo));
            }
        }
    }


    public static void appStatusChange(CircularProgressButton downloadBtn, BaseResInfo baseResInfo, int changeType) {
        appStatusChange(downloadBtn, baseResInfo, changeType, false);
    }

    /**
     * @param downloadBtn
     * @param baseResInfo
     * @param changeType
     * @param matchVersion 严格的版本检查，如果为true，则只有同包名，同versionCode会认为已安装
     *                     ，如果为false，同包名，但是versionCode>=助手库里的包 会认为已安装
     */
    public static void appStatusChange(CircularProgressButton downloadBtn, BaseResInfo baseResInfo, int changeType, boolean matchVersion) {

        if (baseResInfo instanceof ApkResInfo) {
            downloadBtn.setTag(R.id.btn_idle_id, null);
            ApkResInfo apkResInfo = (ApkResInfo) baseResInfo;
            QHDownloadResInfo downloadResInfo = DownloadObjs.downloadInfoMgr.getDownloadInfoById(apkResInfo.getID());
            if (downloadResInfo != null) {
                if (apkResInfo instanceof RankData.RankApkResInfo) {
                    downloadResInfo.isWelfare = ((RankData.RankApkResInfo) apkResInfo).isFromWelfare;
                    downloadResInfo.customBtnText = ((RankData.RankApkResInfo) apkResInfo).welfareText;
                } else if (!TextUtils.isEmpty(apkResInfo.cloudAppId)) {
                    downloadResInfo.isStreamApp = true;
                } else if (ApkResInfo.APP_TYPE_COCOSGAME.equals(apkResInfo.app_type)) {
                    downloadResInfo.isCocosGame = true;
                }
                appStatusChange(downloadBtn, downloadResInfo, changeType, matchVersion);
            } else {
                if (baseResInfo instanceof RankData.RankApkResInfo
                        && ((RankData.RankApkResInfo) baseResInfo).isFromWelfare
                        && !TextUtils.isEmpty(((RankData.RankApkResInfo) baseResInfo).welfareText)) {
                    downloadBtn.setTag(R.id.btn_idle_id, ((RankData.RankApkResInfo) baseResInfo).welfareText);
                } else if (!TextUtils.isEmpty(((ApkResInfo) baseResInfo).cloudAppId)) {
                    downloadBtn.setTag(R.id.btn_idle_id, ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_mk));
                } else if (ApkResInfo.APP_TYPE_COCOSGAME.equals(((ApkResInfo) baseResInfo).app_type)) {
                    downloadBtn.setTag(R.id.btn_idle_id, ContextUtils.getPluginAppContext().getString(R.string.open_text));
                } else if (!TextUtils.isEmpty(baseResInfo.customButtonText)) {
                    downloadBtn.setTag(R.id.btn_idle_id, baseResInfo.customButtonText);
                } else if (((ApkResInfo) baseResInfo).isManageDownSoft) {
                    downloadBtn.setTag(R.id.btn_idle_id, ContextUtils.getPluginAppContext().getString(R.string.add));
                } else if (baseResInfo instanceof SearchApkResInfo && ((SearchApkResInfo) baseResInfo).microType == MicroAppConfig.TYPE_3
                        && !LocalAppManager.getInstance().isAppInstalled(baseResInfo.resPackageName) && MicroAppConfig.isType3OnLine()) {
                    downloadBtn.setTag(R.id.btn_idle_id, ContextUtils.getPluginAppContext().getString(R.string.open_text));
                }
                appStatusChange(downloadBtn, baseResInfo.resPackageName, apkResInfo.versionCode, matchVersion);
            }
        }
    }

    public static void appStatusChange(CircularProgressButton downloadBtn, QHDownloadResInfo downloadResInfo, int changeType) {
        appStatusChange(downloadBtn, downloadResInfo, changeType, false);
    }

    public static void appStatusChange(CircularProgressButton downloadBtn, QHDownloadResInfo downloadResInfo, int changeType, boolean matchVersion) {
        if (downloadResInfo == null) {
            if (LogUtils.isDebug()) {
                throw new RuntimeException("appStatusChange download change");
            }
            return;
        }
        downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_download));
        if (downloadResInfo.isWelfare && !TextUtils.isEmpty(downloadResInfo.customBtnText)) {
            downloadBtn.setIdleText(downloadResInfo.customBtnText);
        } else if (downloadResInfo.isStreamApp) {
            downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_mk));
        } else if (downloadResInfo.isCocosGame) {
            downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.open_text));
        } else if (downloadResInfo.isResultCellData && !TextUtils.isEmpty(downloadResInfo.customBtnText)) {
            downloadBtn.setIdleText(downloadResInfo.customBtnText);
        }

        if (!appStatusChange1(downloadBtn, downloadResInfo, downloadResInfo.resPackageName, downloadResInfo.versionCode, changeType, matchVersion)) {
            appStatusChange2(downloadBtn, downloadResInfo, changeType);
        }
    }

    public static void appStatusChange(CircularProgressButton downloadBtn, String pkgString, String versionCode) {
        appStatusChange(downloadBtn, pkgString, versionCode, false);
    }

    public static void appStatusChange(CircularProgressButton downloadBtn, String pkgString, String versionCode, boolean matchVersion) {
        QHDownloadResInfo dataInfo = DownloadObjs.downloadInfoMgr.getDownloadInfoByPackageName(pkgString);
        if (dataInfo != null && ApkResInfo.NAMEOFTHIRD.equals(dataInfo.downloadFrom)) {
            downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.package_get_string_soft));
            return;
        }
        downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_download));
        Object tag = downloadBtn.getTag(R.id.btn_idle_id);
        if (tag != null && tag instanceof String) {
            downloadBtn.setIdleText((String) tag);
        }
        if (!appStatusChange1(downloadBtn, null, pkgString, versionCode, TYPE_NO_ANIMATION, matchVersion)) {
            QHDownloadResInfo info = DownloadObjs.downloadInfoMgr.getDownloadInfoById(pkgString + versionCode);
            if (info != null && versionCode.equals(info.versionCode)) {
                appStatusChange2(downloadBtn, info, TYPE_NO_ANIMATION);
            } else {
                int process = CircularProgressButton.IDLE_STATE_PROGRESS;
                int progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
                setAppStatus(downloadBtn, process, progressStatus, TYPE_NO_ANIMATION);
            }
        }
    }

    private static boolean appStatusChange1(CircularProgressButton downloadBtn, QHDownloadResInfo downloadResInfo, String pkgString, String versionCode, int changeType, boolean matchVersion) {
        boolean bHandled = true;
        int process;
        int progressStatus;
        int installState = DownloadStateJudge.getInstallState(pkgString, versionCode, matchVersion);
        QHDownloadResInfo dataInfo = DownloadObjs.downloadInfoMgr.getDownloadInfoByPackageName(pkgString);
        if (dataInfo != null && ApkResInfo.NAMEOFTHIRD.equals(dataInfo.downloadFrom)) {
            downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.package_get_string_soft));
            return false;
        }
        if (DownloadStateJudge.isInstalled(installState, true)) {
            if (installState == DownloadStateJudge.APK_INSTALLED_FOR_360OS
                /*SafetyFieldUtils.isInstallSafety(ContextUtils.getPluginAppContext(),
                pkgString, ClientInfoManager.isMainActivityExist())*/) {
                process = CircularProgressButton.INSTALLED_STATE_PROGRESS;
            } else {
                process = CircularProgressButton.OPEN_STATE_PROGRESS;
            }
            progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            setAppStatus(downloadBtn, process, progressStatus, changeType);
        } else if (DownloadStateJudge.isUpGrade(installState)) {
            if (downloadResInfo != null) {
                int[] processArray = handleDownloadStatus(downloadBtn, downloadResInfo);
                process = processArray[0];
                progressStatus = processArray[1];
            } else {
                process = CircularProgressButton.IDLE_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            }
            downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_update));
            //如果是鸿蒙应用，显示打开
            if (ApkUtils.isHarmonyApp(pkgString)) {
                downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.open_text));
            }
            setAppStatus(downloadBtn, process, progressStatus, changeType);
        } else if (DownloadStateJudge.isDownGrade(installState)) {
            if (downloadResInfo != null) {
                int[] processArray = handleDownloadStatus(downloadBtn, downloadResInfo);
                process = processArray[0];
                progressStatus = processArray[1];
            } else {
                process = CircularProgressButton.IDLE_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            }
            setAppStatus(downloadBtn, process, progressStatus, changeType);
        } else {
            bHandled = false;
        }

        return bHandled;

    }

    private static void appStatusChange2(CircularProgressButton downloadBtn, QHDownloadResInfo downloadResInfo, int changeType) {
        int process = CircularProgressButton.IDLE_STATE_PROGRESS;
        int progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
        QHDownloadResInfo dataInfo = DownloadObjs.downloadInfoMgr.getDownloadInfoByPackageName(downloadResInfo.resPackageName);
        if (dataInfo != null && ApkResInfo.NAMEOFTHIRD.equals(dataInfo.downloadFrom)) {
            downloadBtn.setIdleText(ContextUtils.getPluginAppContext().getString(R.string.package_get_string_soft));
            return;
        }
        if (downloadResInfo != null && InstallManager.getInstance().isInstalling(downloadResInfo.id)) {
            if (downloadResInfo.getProcessingBeforeInstall() == 1) {
                process = CircularProgressButton.PROCESS_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            } else if (downloadResInfo.getProcessingBeforeInstall() == 3) {
                process = CircularProgressButton.MERGE_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            } else {
                process = CircularProgressButton.INSTALLING_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            }
        } else {
            int[] processArray = handleDownloadStatus(downloadBtn, downloadResInfo);
            process = processArray[0];
            progressStatus = processArray[1];
        }

        setAppStatus(downloadBtn, process, progressStatus, changeType);
    }

    public static void setAppStatus(CircularProgressButton downloadBtn, int process, int progressStatus, int changeType) {
        if (changeType == TYPE_GENTLE) {
            downloadBtn.setProgress(process, progressStatus);
        } else if (changeType == TYPE_NO_ANIMATION) {
            downloadBtn.setCurrentState(process, progressStatus);
        }
    }

    private static int[] handleDownloadStatus(CircularProgressButton downloadBtn, QHDownloadResInfo downloadResInfo) {
        int status = downloadResInfo.mStatus;
        int process = CircularProgressButton.IDLE_STATE_PROGRESS;
        int progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;

        if (status == DownloadConsts.Status.STATUS_PENDING) {
            process = CircularProgressButton.WAITING_STATE_PROGRESS;
            progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
        } else if (status == DownloadConsts.Status.STATUS_RUNNING
                || status == DownloadConsts.Status.STATUS_CONTINUE_PENDING) {
            if (downloadBtn.getProgressEnable()) {
                process = Math.min(100, (int) (downloadResInfo.mCurrentBytes * 100.0 / downloadResInfo.mTotalBytes));
                progressStatus = CircularProgressButton.PROGRES_SATUS_RUNNING;
            } else {
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
                if (status == DownloadConsts.Status.STATUS_CONTINUE_PENDING) {
                    process = CircularProgressButton.WAITING_STATE_PROGRESS;
                } else {
                    process = CircularProgressButton.RUNNING_PROGRESS_DISABLE_STATE_PROGRESS;
                }
            }
        } else if (status == DownloadConsts.Status.STATUS_PAUSING
                || status == DownloadConsts.Status.STATUS_CANCELING) {
            if (downloadBtn.getProgressEnable()) {
                process = Math.min(100, (int) (downloadResInfo.mCurrentBytes * 100.0 / downloadResInfo.mTotalBytes));
                progressStatus = CircularProgressButton.PROGRES_STATUS_PAUSING;
            } else {
                process = CircularProgressButton.WAITING_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            }
        } else if (status == DownloadConsts.Status.STATUS_PAUSED) {
            // process = (int) (downloadResInfo.mCurrentBytes * 100.0 / downloadResInfo.mTotalBytes);
            if (downloadResInfo.getPausedByUser() == 0) {
                process = CircularProgressButton.WAITWIFI_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            } else {
                process = CircularProgressButton.PAUSE_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_PAUSE;
            }
//            process = CircularProgressButton.PAUSE_STATE_PROGRESS;
//            progressStatus = CircularProgressButton.PROGRES_SATUS_PAUSE;
        } else if (status == DownloadConsts.Status.STATUS_ERROR_IN_DATA_NET) {
            process = CircularProgressButton.WAITWIFI_STATE_PROGRESS;
            progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
        } else if (DownloadConsts.isDownloadError(status)) {
            process = CircularProgressButton.ERROR_STATE_PROGRESS;
            progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
        } else if (status == DownloadConsts.Status.STATUS_SUCCESS) {
            if (downloadResInfo.getProcessingBeforeInstall() == 1) {
                process = CircularProgressButton.PROCESS_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            } else if (downloadResInfo.getProcessingBeforeInstall() == 3) {
                process = CircularProgressButton.MERGE_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            } else if (!FileUtils.pathFileExist(downloadResInfo.savePath)) {
                //下载完成了，但是安装包丢失了，显示"下载"
                process = CircularProgressButton.IDLE_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            } else {
                process = CircularProgressButton.SUCCESS_STATE_PROGRESS;
                progressStatus = CircularProgressButton.PROGRES_SATUS_IDLE;
            }
        }

        return new int[]{process, progressStatus};
    }

    private static String getP2pDownloadErrInfo(Context context, int status) {
        switch (status) {
            case DownloadConsts.Status.NEW_DL_TASK_URL_ERROR:
            case DownloadConsts.Status.NEW_DL_TASK_UNINITED:
            case DownloadConsts.Status.NEW_DL_TASK_PARAM_ERROR:
                return context.getString(R.string.new_dl_init_task_error);
            case DownloadConsts.Status.NEW_DL_TASK_OOM:
                return context.getString(R.string.new_dl_oom);
            case DownloadConsts.Status.NEW_DL_TASK_OUT_USE_IP:
            case DownloadConsts.Status.NEW_DL_TASK_HTTP_INIT_FAILED:
            case DownloadConsts.Status.NEW_DL_TASK_AUTH_FAILED:
            case DownloadConsts.Status.NEW_DL_TASK_SOCKET_INIT_FAILED:
            case DownloadConsts.Status.NEW_DL_TASK_SOCKCET_EXCEPTION:
            case DownloadConsts.Status.NEW_DL_TASK_FAIL_FETCH_FILE_SIZE:
            case DownloadConsts.Status.NEW_DL_TASK_DNS_FAILED:
            case DownloadConsts.Status.NEW_DL_TASK_NETWORK_OFF:
                return context.getString(R.string.new_dl_network_error) + "(" + status + ")";
            case DownloadConsts.Status.NEW_DL_TASK_CREATE_FILE_FAILED:
                return context.getString(R.string.new_dl_create_file_error);
            case DownloadConsts.Status.NEW_DL_TASK_READ_FILE_FAILED:
                return context.getString(R.string.new_dl_read_file_error);
            case DownloadConsts.Status.NEW_DL_TASK_WRITE_FILE_FAILED:
                return context.getString(R.string.new_dl_write_file_error);
            case DownloadConsts.Status.NEW_DL_TASK_RENAME_FILE_FAILED:
                return context.getString(R.string.new_dl_rename_file_error);
            case DownloadConsts.Status.NEW_DL_TASK_UNKNOWN_ERROR:
            case DownloadConsts.Status.NEW_DL_TASK_UNKNOWN_ERROR2:
                return context.getString(R.string.new_dl_unknown_error);
            case DownloadConsts.Status.NEW_DL_TASK_IO_ERROR:
                //查看是否空间不足
                if (SDCardUtils.GetAvailableSpace(ContextUtils.getPluginAppContext()) < 1024 * 1024) {
                    return context.getString(R.string.store_space_not_enough1) + "(" + status + ")";
                }
                return context.getString(R.string.new_dl_io_error);
            case DownloadConsts.Status.NEW_DL_TASK_NO_SPACE_ERROR: {
                return context.getString(R.string.store_space_not_enough1) + "(" + status + ")";
            }
            case DownloadConsts.Status.NEW_DL_TASK_IO_DATA_ERROR: {
                return context.getString(R.string.new_dl_io_error);
            }
            case DownloadConsts.Status.NEW_DL_ERROR_URL:
                return context.getString(R.string.new_dl_url_error);
        }

        if (status <= DownloadConsts.Status.NEW_DL_SOCKET_TIMEOUT1 && status >= DownloadConsts.Status.NEW_DL_SOCKET_TIMEOUT2) {
            return context.getString(R.string.new_dl_socket_error) + "(" + status + ")";
        }

        if (status <= DownloadConsts.Status.NEW_DL_SOCKET_ERROR1 && status >= DownloadConsts.Status.NEW_DL_SOCKET_ERROR2) {
            return context.getString(R.string.new_dl_socket_error) + "(" + status + ")";
        }

        if (status <= DownloadConsts.Status.NEW_DL_HTTP_SERVER_ERROR1 && status >= DownloadConsts.Status.NEW_DL_HTTP_SERVER_ERROR2) {
            return context.getString(R.string.new_dl_http_error) + "(" + status + ")";
        }

        if (status <= DownloadConsts.Status.NEW_DL_HTTP_AUTH_ERROR1 && status >= DownloadConsts.Status.NEW_DL_HTTP_AUTH_ERROR2) {
            return context.getString(R.string.new_dl_http_error) + "(" + status + ")";
        }

        return null;
    }

    private static String getHttpDownloadErrInfo(Context context, int status) {
        switch (status) {
            case DownloadConsts.Status.STATUS_NOT_ACCEPTABLE:
                return context.getString(R.string.download_not_acceptable);

            case DownloadConsts.Status.STATUS_LENGTH_REQUIRED:
                return context.getString(R.string.download_length_required);

            case DownloadConsts.Status.STATUS_PRECONDITION_FAILED:
                return context.getString(R.string.download_precondition_failed);

            case DownloadConsts.Status.STATUS_CANCELED:
                return context.getString(R.string.download_canceled);

            case DownloadConsts.Status.STATUS_MERGE_ERROR:
                return context.getString(R.string.merge_error);

            case DownloadConsts.Status.STATUS_BAD_REQUEST:
            case DownloadConsts.Status.STATUS_UNKNOWN_ERROR:
            case DownloadConsts.Status.STATUS_HTTP_EXCEPTION:
            case DownloadConsts.Status.STATUS_HTTP_DATA_ERROR:
                return context.getString(R.string.download_network_error);


        }

        return null;
    }

    public static String getDownloadErrInfo(Context context, QHDownloadResInfo info) {
        String ret = getHttpDownloadErrInfo(context, info.mStatus);
        if (TextUtils.isEmpty(ret)) {
            ret = getP2pDownloadErrInfo(context, info.mStatus);
            if (TextUtils.isEmpty(ret)) {
                switch (info.mStatus) {
                    case DownloadConsts.Status.STATUS_ERROR_IN_DATA_NET:
                        ret = context.getString(R.string.new_dl_network_error_wait_wifi);
                        break;
                    case DownloadConsts.Status.STATUS_NETWORK_NOT_OK:
                        ret = context.getString(R.string.new_dl_network_error);
                        break;
                    case DownloadConsts.Status.STATUS_INSUFFICIENT_SPACE_ERROR:
                        ret = context.getString(R.string.store_space_not_enough1);
                        break;
                    case DownloadConsts.Status.STATUS_FILE_ERROR:
                        ret = context.getString(R.string.download_error);
                        if (info.mErrorCode == DownloadConsts.ErrCode.ERR_CHECK_FILE_LENGTH_WHEN_CONNECT ||
                                info.mErrorCode == DownloadConsts.ErrCode.ERR_CHECK_FILE_LENGTH_WHEN_FINISH ||
                                info.mErrorCode == DownloadConsts.ErrCode.ERR_CHECK_FILE_MD5_WHEN_FINISH ||
                                info.mErrorCode == DownloadConsts.ErrCode.ERR_CHECK_FILE_NOT_APK_WHEN_FINISH ||
                                info.mErrorCode == DownloadConsts.ErrCode.ERR_CREATE_DOWNLOAD_PATH_ERR ||
                                info.mErrorCode == DownloadConsts.ErrCode.ERR_NOT_ENOUGH_SPACE
                        ) {
                            ret = context.getString(R.string.new_dl_check_file_when_finish) + ("(" + info.mErrorCode + ")");
                        }
                        break;
                    case DownloadConsts.Status.STATUS_UNKNOWN_ERROR:
                        ret = context.getString(R.string.new_dl_write_file_error);
                        break;

                    case DownloadConsts.Status.STATUS_MERGE_ERROR:
                        ret = context.getString(R.string.merge_error);
                        break;
                    default: {
                        ret = context.getString(R.string.new_dl_unknown_error) + "(" + info.mStatus + ")";
                        break;
                    }
                }// end switch
            }
        }

        return ret;

    }

    public static class InstallChecker {
        public boolean isApkInstalled(Context context, String resId, String verCode) {
            return LocalAppManager.getInstance().isAppInstalled(resId, verCode);
        }
    }

    public static String getLabel(BaseResInfo info, String label) {
        return (RecommendApkResInfo.isRecommendApkResInfo(info) ? StatFieldConst.LABEL_RECOMMEND_LIST : label);
    }

    public static State getAppState(String pkgString, String versionCode, boolean matchVersion) {
       QHDownloadResInfo downloadResInfo = DownloadManager.getInstance().getDownloadResInfo(pkgString + versionCode);
        State state = getInstallState(pkgString, versionCode, matchVersion, downloadResInfo);
        if (state == null || !LocalAppManager.getInstance().isAppInstalled(pkgString)) {
            state = getDownloadState(downloadResInfo);
        }
        return state;
    }

    private static State getInstallState(String pkgString, String versionCode, boolean matchVersion, QHDownloadResInfo downloadResInfo) {
        int installState = DownloadStateJudge.getInstallState(pkgString, versionCode, matchVersion);
        if (DownloadStateJudge.isInstalled(installState, true)) {
            if (installState == DownloadStateJudge.APK_INSTALLED_FOR_360OS) {
                return State.INSTALLED;
            } else {
                return State.OPEN;
            }
        } else if (DownloadStateJudge.isUpGrade(installState) && downloadResInfo == null) {
            //如果已安装的应用是鸿蒙应用,不显示“更新”状态，而显示“打开”.
            if (ApkUtils.isHarmonyApp(pkgString)) {
                return State.OPEN;
            } else {
                return State.UPDATED;
            }
        } else if (DownloadStateJudge.isDownGrade(installState)) {//实际安装的版本 > 接口返回的版本，也显示打开
            return State.OPEN;
        }
        return null;
    }

    private static State getDownloadState(QHDownloadResInfo downloadResInfo) {
        State state = IDLE;
        if (downloadResInfo != null) {
            switch (downloadResInfo.mStatus) {
                case DownloadConsts.Status.STATUS_PENDING:
                case DownloadConsts.Status.STATUS_PAUSING:
                case DownloadConsts.Status.STATUS_CONTINUE_PENDING:
                case DownloadConsts.Status.STATUS_CANCELING:
                    state = State.WAITING;
                    break;
                case DownloadConsts.Status.STATUS_RUNNING:
                    state = State.PROGRESSING;
                    break;
                case DownloadConsts.Status.STATUS_PAUSED:
                    state = State.PAUSED;
                    break;
                case DownloadConsts.Status.STATUS_ERROR_IN_DATA_NET:
                    state = State.WAITWIFI;
                    break;
                case DownloadConsts.Status.STATUS_SUCCESS:
                    if (downloadResInfo.getProcessingBeforeInstall() == 1) {
                        state = State.PROCESS;
                    } else if (downloadResInfo.getProcessingBeforeInstall() == 3) {
                        state = State.MERGE;
                    } else if (InstallManager.getInstance().isInstalling(downloadResInfo.id)) {
                        state = State.INSTALLING;
                    } else if (FileUtils.pathFileExist(downloadResInfo.savePath)) {
                        state = State.COMPLETE;
                    }
                default:
                    if (DownloadConsts.isDownloadError(downloadResInfo.mStatus)) {
                        state = State.ERROR;
                    }
            }
        }
        return state;
    }
    public static String getStatusText(int resType, String resId, String pkgName, String verCode, boolean ignoreInstallCheck, InstallChecker checker,HorizontalProgressButton horizontalProgressButton) {

        String statusString = ContextUtils.getPluginAppContext().getString(
                R.string.download_btn_text_download);

        QHDownloadResInfo info = DownloadObjs.downloadInfoMgr.getDownloadInfoById(resId);

        if ((resType == Consts.ResType.RESTYPE_APK || QHDownloadResInfo.canUrlAsApk(info))
                && !ignoreInstallCheck
                && checker.isApkInstalled(ContextUtils.getPluginAppContext(), pkgName, verCode) && (info == null || DownloadConsts.isStatusSuccess(info.mStatus))) {
            statusString = ContextUtils.getPluginAppContext().getString(R.string.open_text);
            horizontalProgressButton.setOpenText(statusString);
            if (SafetyFieldUtils.isInstallFor360OS(pkgName, ClientInfoManager.isMainActivityExist())) {
                statusString = ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_installed);
                horizontalProgressButton.setOpenText(statusString);

            }
            horizontalProgressButton.setState(HorizontalProgressButton.State.OPEN);
        } else {
            if (info == null) {
                statusString = ContextUtils.getPluginAppContext().getString(
                        R.string.download_btn_text_download);
                horizontalProgressButton.setState(HorizontalProgressButton.State.IDLE);
            } else {
                if ((resType == Consts.ResType.RESTYPE_APK || QHDownloadResInfo.canUrlAsApk(info))
                        && InstallManager.getInstance().isInstalling(info.id)
                        && !info.isApkDataTask()) {
                    statusString = ContextUtils.getPluginAppContext().getString(R.string.btn_install_installing);
                    horizontalProgressButton.setState(HorizontalProgressButton.State.INSTALLING);
                } else {
                    switch (info.mStatus) {
                        case DownloadConsts.Status.STATUS_RUNNING:
                            long totalSize = info.mTotalBytes;
                            if (totalSize == 0 && info.showSize != 0) {
                                totalSize = info.showSize;
                            }
                            if (totalSize > 0) {
                                int progress = (int) (info.mCurrentBytes * 100.0 / totalSize);
                                horizontalProgressButton.setProgress(progress);
                            }
                            horizontalProgressButton.setState(HorizontalProgressButton.State.PROGRESSING);
                            statusString = ContextUtils.getPluginAppContext()
                                    .getString(R.string.download_btn_text_pause);
                            break;
                        case DownloadConsts.Status.STATUS_PENDING:
                        case DownloadConsts.Status.STATUS_CONTINUE_PENDING:
                            horizontalProgressButton.setState(HorizontalProgressButton.State.WAITING);
                            statusString = ContextUtils.getPluginAppContext()
                                    .getString(R.string.download_btn_text_pending);
                            break;
                        case DownloadConsts.Status.STATUS_PAUSING:
                            horizontalProgressButton.setState(HorizontalProgressButton.State.PAUSED);
                            statusString = ContextUtils.getPluginAppContext()
                                    .getString(R.string.download_btn_text_pausing);
                            break;
                        case DownloadConsts.Status.STATUS_PAUSED:
                            horizontalProgressButton.setState(HorizontalProgressButton.State.PAUSED);
                            statusString = ContextUtils.getPluginAppContext()
                                    .getString(R.string.download_btn_text_continue);
                            break;
                        case DownloadConsts.Status.STATUS_SUCCESS:
                            if (info.isApkDataTask() && info.getIsUnZipSuc()) {
                                horizontalProgressButton.setState(HorizontalProgressButton.State.OPEN);
                                statusString = ContextUtils.getPluginAppContext().getResources().getString(R.string.open_text);
                            } else if (info.getProcessingBeforeInstall() == 1) {
                                horizontalProgressButton.setState(HorizontalProgressButton.State.PROCESS);
                                statusString = ContextUtils.getPluginAppContext().getResources().getString(R.string.unziping);
                            } else if (info.getProcessingBeforeInstall() == 3) {
                                horizontalProgressButton.setState(HorizontalProgressButton.State.MERGE);
                                statusString = ContextUtils.getPluginAppContext().getResources().getString(R.string.btn_text_merge);
                            } else if (info.resType == Consts.ResType.RESTYPE_APK || QHDownloadResInfo.canUrlAsApk(info)) {
                                if (InstallManager.getInstance().isInstalling(info.id)) {
                                    horizontalProgressButton.setState(HorizontalProgressButton.State.INSTALLING);
                                    statusString = ContextUtils.getPluginAppContext().getResources().getString(R.string.btn_install_installing);
                                } else if (QHDownloadResInfo.isLosePackageApk(info)) {
                                    horizontalProgressButton.setState(HorizontalProgressButton.State.COMPLETE);
                                    statusString = ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_download);
                                } else {
                                    horizontalProgressButton.setState(HorizontalProgressButton.State.COMPLETE);
                                    statusString = ContextUtils.getPluginAppContext().getResources().getString(R.string.download_btn_text_install);
                                }
                            } else {
                                statusString = DownloadVariousResHelper.getSucString(info.resType);
                            }
                            break;
                        case DownloadConsts.Status.STATUS_ERROR_IN_DATA_NET:
                            horizontalProgressButton.setState(HorizontalProgressButton.State.IDLE);
                            statusString = ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_download_directly_short);
                            break;
                        default:
                            if (DownloadConsts.isDownloadError(info.mStatus)) {
                                statusString = ContextUtils.getPluginAppContext().getString(R.string.download_btn_text_error);
                                horizontalProgressButton.setState(HorizontalProgressButton.State.ERROR);
                            }
                            break;
                    }
                }
            }
        }

        return statusString;
    }


}
