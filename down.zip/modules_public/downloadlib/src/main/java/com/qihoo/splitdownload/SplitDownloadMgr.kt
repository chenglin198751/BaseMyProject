package com.qihoo.splitdownload

import android.text.TextUtils
import com.qihoo.appstore.data.plugin.config.BuildConfigGlobal
import com.qihoo.utils.LogUtils
import com.qihoo.utils.compat.EnvironmentCompat
import com.qihoo360.common.BuildConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import java.io.File

/**
 * Created by caiyingyuan on 2023/10/16
 */
object SplitDownloadMgr {

    const val TAG = "SplitDownloadMgr"
    private val SPLIT_COUNT = 5 //切成5片下载
    private val SPLIT_SIZE = 5 * 1024 * 1024L //每片5M

    const val FAIL_TYPE_NO_SUPPORT = 1
    const val FAIL_TYPE_OTHER = 2

    // apk>=100mb才启动切片下载
    private val SUPPORT_SPLITE_GAME_SIZE = 100 * 1024 * 1024L

    object SplitDownloadStat {
        const val EVENT_ID = "split_download"
        const val ACTION_START_DOWNLOAD = "start_download"
        const val ACTION_DOWNLOAD_SUC = "download_suc"
        const val ACTION_DOWNLOAD_FAIL = "download_fail"
        const val ACTION_MERGE_SUC = "merge_suc"
        const val ACTION_MERGE_FAIL = "merge_fail"
        const val ACTION_ALL_FILE_DOWN_SUC = "split_file_download_finish"
    }

    //支持下载的dsp_cid
    private val supportSplitCid = arrayOf(
            "149",  //穿山甲
            "151",  //华为adx
            "164" //百青藤
    )

    private val tasks = HashMap<String, Job>()

    interface IDownloadSpeedCallback {
        fun onRequestInfo(type: Int, isRedirect: Boolean)
        fun onDownloadStart(info: SplitTaskInfo)
        fun onDownloadCallBack(info: SplitTaskInfo, progress: Int)
        fun onDownloadSuc()
        fun onSplitFileDownload()
        fun onMergeResult(isSuc: Boolean)

        fun onDownloadFail(type: Int, e: Exception)
        fun onDownloadCancel()
    }

    interface ISplitDownloadCallback {
        fun onDownloadSize(bytesCopied: Long)
        fun onDownloadFail(e: Exception)
        fun onDownloadCancel()
    }


    fun isSupportGame(isGame: Boolean, mTotalBytes: Long): Boolean {
        val bRet = isGame && mTotalBytes >= SUPPORT_SPLITE_GAME_SIZE
        return bRet
    }

    fun isSupportCid(dspCid: String?): Boolean {
        var supportCid = !dspCid.isNullOrEmpty() && supportSplitCid.contains(dspCid)
        if (BuildConfig.DEBUG) {
//            supportCid = !TextUtils.isEmpty(dspCid) //方便测试cid不为空使用分片
        }
        return supportCid

    }

    fun getTimeFormat(start: Long): String {
        val time = (System.currentTimeMillis() - start) / 1000f
        return "耗时：${String.format("%.2f", time)}秒"
    }

    fun deleteTempFile(savePath: String?) {
        if (TextUtils.isEmpty(savePath)) {
            return
        }
        val rootDir = File(savePath).parentFile

        val taskName = getTaskName(savePath)
        val target = getSaveFile(rootDir, taskName)
        if (target.exists()) {
            target.delete()
        }

        val tmpFile = File(target.parentFile, "${taskName}.incomplete")
        if (tmpFile.exists()) {
            tmpFile.delete()
        }
        val tempDir = File(target.parentFile, "${taskName}_temp")
        deleteSplitTempDir(tempDir)
    }

    fun deleteSplitTempDir(tempDir: File) {
        if (!tempDir.exists() || !tempDir.isDirectory) return

        tempDir.walkBottomUp().forEach {
            try {
                if (!it.delete()) {
                    if (LogUtils.isDebug()) {
                        LogUtils.e(TAG, "删除失败: ${it.absolutePath}")
                    }
                }
            } catch (e: Exception) {
                if (LogUtils.isDebug()) {
                    LogUtils.e(TAG, "删除失败: ${it.absolutePath}, ${e.message}")
                }
            }
        }
    }

    fun isTaskRunning(info: SplitTaskInfo): Boolean {
        val task: Job? = synchronized(tasks) {
            try {
                tasks[info.taskName]
            } catch (tr: Throwable) {
                null
            }
        }
        return task != null
    }

    fun cancelDownload(info: SplitTaskInfo) {
        if (LogUtils.isDebug()) {
            LogUtils.v(TAG, "cancelDownload ${info.taskName}")
        }
        info.mDownloadStatus = SplitTaskInfo.DOWNLOAD_STATUS_CANCELING

        val jobToWait: Job?
        synchronized(tasks) {
            if (LogUtils.isDebug()) {
                LogUtils.v(TAG, "cancelDownload ${info.taskName} splitDownloadInfo: ${info.splitDownloadInfo}")
            }
            info.splitDownloadInfo?.cancelJob()
            jobToWait = tasks[info.taskName]
            jobToWait?.cancel(CancellationException("cancelDownload"))
            tasks.remove(info.taskName)
        }

        // 等待协程真正停止后再返回，防止旧协程还在写分片文件时新任务就启动了
        jobToWait?.let { job ->
            if (!job.isCompleted) {
                runBlocking {
                    try {
                        withTimeout(5000L) { job.join() }
                    } catch (e: Exception) {
                        LogUtils.e(TAG, "cancelDownload ${info.taskName} 等待协程结束超时或异常: ${e.message}")
                    }
                }
            }
        }
        if (LogUtils.isDebug()) {
            LogUtils.v(TAG, "cancelDownload ${info.taskName} 协程已停止")
        }
    }

    fun getTaskName(savePath: String?): String {
        val paths = savePath?.split("/")
        return paths?.get(paths.size - 1)?.replace(".apk", "") ?: ""
    }

    fun startDownload(info: SplitTaskInfo, callback: IDownloadSpeedCallback) {
        val task: Job? = synchronized(tasks) {
            try {
                tasks[info.taskName]
            } catch (tr: Throwable) {
                null
            }
        }

        CoroutineScope(Dispatchers.IO).launch {
            task?.let {
                if (LogUtils.isDebug()) {
                    LogUtils.v(TAG, "previous ${info.taskName} task is running, waiting..")

                }
                it.join()
            }
            if (LogUtils.isDebug()) {
                LogUtils.v(TAG, "start ${info.taskName}")
            }

            val startTime = System.currentTimeMillis()
            callback.onRequestInfo(0, false)
            val jsonObject = SplitDownloader.getDownloadRangeInfo(info.downloadUrl, 0, 0)
            if (LogUtils.isDebug()) {
                LogUtils.d(TAG, "startSplitDownload getDownloadRangeInfo, 耗时：${System.currentTimeMillis() - startTime}, json: $jsonObject")
            }
            val rangeInfo = jsonObject.optString("range")
            val url = jsonObject.optString("url")
            val isRedirect = jsonObject.optBoolean("isRedirect")
            if (!TextUtils.isEmpty(url)) {
                info.downloadUrl = url
            }
            callback.onRequestInfo(1, isRedirect)
            if (TextUtils.isEmpty(rangeInfo)) {
                callback.onDownloadFail(FAIL_TYPE_NO_SUPPORT, RuntimeException("不支持分片下载"))
            } else {
                try {
                    rangeInfo.split("/").apply {
                        val totalSize = get(1).toLong()
                        info.totalSize = totalSize
                        callback.onDownloadStart(info)
                        val target = info.saveFile ?: getSaveFile(info)
                        SplitDownloader.downloadByRangeFromCount(info, target, SPLIT_COUNT, totalSize, callback)
                        info.saveFile = target
                    }
                } catch (e: Exception) {
                    callback.onDownloadFail(FAIL_TYPE_OTHER, e)
                }
            }
        }.also { job ->
            job.invokeOnCompletion {
                synchronized(tasks) {
                    try {
                        if (tasks[info.taskName] == job) {
                            tasks.remove(info.taskName)
                        }
                    } catch (tr: Throwable) {
                    }
                }
                if (LogUtils.isDebug()) {
                    LogUtils.v(TAG, "start ${info.taskName} completed: $it")
                }
            }
            synchronized(tasks) {
                tasks.put(info.taskName, job)
            }
        }

    }

    fun getTempDir(target: File, info: SplitTaskInfo): File {
        val tempDir = File(target.parentFile, "${info.taskName}_temp")
        if (!tempDir.exists()) {
            tempDir.mkdirs()
        }
        return tempDir
    }

    fun getSaveFile(taskInfo: SplitTaskInfo): File {
        return getSaveFile(taskInfo.rootDir ?: getDefRootDir(), taskInfo.taskName)
    }

    fun getSaveFile(rootDir: File, fileName: String): File {
        val dir = File(rootDir, "SplitDownload")
        if (!dir.exists()) {
            dir.mkdirs()
        }

        val pkgName = fileName + "_split"
        return File(dir, "$pkgName.apk")
    }

    private fun getDefRootDir(): File {
        return EnvironmentCompat.getExternalStorageDirectory()
    }


}