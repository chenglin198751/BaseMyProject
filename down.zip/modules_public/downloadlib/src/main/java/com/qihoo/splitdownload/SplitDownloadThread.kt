package com.qihoo.splitdownload

import android.content.Context
import android.content.Intent
import android.text.TextUtils
import android.util.Log
import com.qihoo.appstore.data.plugin.constant.DownloadConsts
import com.qihoo.appstore.data.plugin.info.DownloadResInfo
import com.qihoo.download.IDownloadDelegate
import com.qihoo.httpdownload.HttpDownloadThread
import com.qihoo.utils.ContextUtils
import com.qihoo.utils.FileUtils
import com.qihoo.utils.LogUtils
import java.io.File

class SplitDownloadThread(
        val context: Context,
        val downloadResInfo: DownloadResInfo,
        val downloadDelegate: IDownloadDelegate
) : Runnable {
    private val TAG = SplitDownloadMgr.TAG + "_SplitDownloadThread"
//    private lateinit var taskInfo: SplitTaskInfo

    override fun run() {
        if (TextUtils.isEmpty(downloadResInfo.savePath)) {
            downloadDelegate.getRetryPath(downloadResInfo)
        }
        val paths = downloadResInfo.savePath?.split("/")
        val fileName = paths?.get(paths.size - 1)?.replace(".apk", "") ?: ""
        val taskInfo = SplitTaskInfo(taskName = fileName, downloadUrl = downloadResInfo.downloadUrl)
        taskInfo.rootDir = File(downloadResInfo.savePath).parentFile
        taskInfo.saveFile = SplitDownloadMgr.getSaveFile(taskInfo)

        if (SplitDownloadMgr.isTaskRunning(taskInfo)) {
            LogUtils.e(TAG, "running splitDownload() $taskInfo ")
            downloadResInfo.isDownloadRunning = false
            return
        }
        downloadResInfo.mCurrentBytes = SplitTaskInfo.getDownloadedBytes(taskInfo)
        LogUtils.e(TAG, "run before startSplitDownload() $taskInfo  mCurrentBytes: ${downloadResInfo.mCurrentBytes}, mTotalBytes: ${downloadResInfo.mTotalBytes}" )

        downloadDelegate.onStartDownload(downloadResInfo)

        val startTime = System.currentTimeMillis()
        var requestStart = 0L
        var downStart = 0L

        SplitDownloadMgr.startDownload(taskInfo, object : SplitDownloadMgr.IDownloadSpeedCallback{
            override fun onRequestInfo(type: Int, isRedirect: Boolean) {
                if (type == 0) {
                    requestStart = System.currentTimeMillis()
                } else {
                    if (LogUtils.isDebug()) {
                        LogUtils.d(SplitDownloadMgr.TAG, "分片下载-请求下载信息, ${getTimeFormat(requestStart)} downloadUrl: ${taskInfo.downloadUrl}")
                    }
                    if (isRedirect) {
                        downloadDelegate.onRedirect(taskInfo.downloadUrl)
                        downloadResInfo.downloadUrl = taskInfo.downloadUrl
                    }

                }
            }

            override fun onDownloadStart(info: SplitTaskInfo) {
                downStart = System.currentTimeMillis()
                if (LogUtils.isDebug()) {
                    LogUtils.d(SplitDownloadMgr.TAG, "onDownloadStart ${info.taskName} totalSize: ${info.totalSize}")
                }
                downloadDelegate.onSplitStat(
                        downloadResInfo,
                        SplitDownloadMgr.SplitDownloadStat.ACTION_START_DOWNLOAD,
                        null
                )
            }

            override fun onDownloadCallBack(info: SplitTaskInfo, progress: Int) {
                if (LogUtils.isDebug()) {
//                LogUtils.d(SplitDownloadMgr.TAG, "onDownloadCallBack: ${info.taskName} ${info.mSpeedText}, progress:" + progress)
                }
                handleProgress(info)
            }

            override fun onDownloadSuc() {
                refreshDownloadSuc(taskInfo, "分5片", startTime)

                taskInfo.saveFile?.let {
                    FileUtils.moveFile(it.absolutePath, downloadResInfo.savePath)
                }
                downloadDelegate.onDownloadSucceed(downloadResInfo, "", "", composeParams(), false, false, 0, false)
                downloadResInfo.mStatus = DownloadConsts.Status.STATUS_SUCCESS
                downloadDelegate.onSplitStat(
                        downloadResInfo,
                        SplitDownloadMgr.SplitDownloadStat.ACTION_DOWNLOAD_SUC,
                        null
                )

            }

            override fun onSplitFileDownload() {
                if (LogUtils.isDebug()) {
                    val tips = "所有分片下载完成, , ${getTimeFormat(startTime)}"
                    LogUtils.d(SplitDownloadMgr.TAG, "onSplitFileDownload: $tips")
                    LogUtils.d(SplitDownloadMgr.TAG, "分片下载-${getTimeFormat(downStart)}")
                }
                downloadDelegate.onSplitStat(
                        downloadResInfo,
                        SplitDownloadMgr.SplitDownloadStat.ACTION_ALL_FILE_DOWN_SUC,
                        null
                )
            }

            override fun onMergeResult(isSuc: Boolean) {
                downloadDelegate.onSplitStat(
                        downloadResInfo, if (isSuc) {
                    SplitDownloadMgr.SplitDownloadStat.ACTION_MERGE_SUC
                } else SplitDownloadMgr.SplitDownloadStat.ACTION_MERGE_FAIL, null
                )
            }

            override fun onDownloadFail(type: Int, e: Exception) {
                if (LogUtils.isDebug()) {
                    LogUtils.d(SplitDownloadMgr.TAG, "$taskInfo onDownloadFail type: $type", Throwable(e))
                }

                if (type == SplitDownloadMgr.FAIL_TYPE_NO_SUPPORT) {
                    if (LogUtils.isDebug()) {
                        LogUtils.d(SplitDownloadMgr.TAG, "$taskInfo onDownloadFail type: $type, 不支持分片，切换为普通下载" )
                    }
                    val mainWorker = HttpDownloadThread(context, downloadResInfo, downloadDelegate)
                    mainWorker.run()
                } else {
                    refreshDownloadFail("分5片")
                    downloadResInfo.mStatus = DownloadConsts.Status.STATUS_UNKNOWN_ERROR
                    handleFinish()
                }
                downloadDelegate.onSplitStat(downloadResInfo, SplitDownloadMgr.SplitDownloadStat.ACTION_DOWNLOAD_FAIL, e.message)
            }

            override fun onDownloadCancel() {
                Log.d(SplitDownloadMgr.TAG, "$taskInfo onDownloadCancel")
                handleFinish(true)
            }
        })
        checkDownloadStatus(taskInfo)

    }

    private fun checkDownloadStatus(info: SplitTaskInfo) {
        LogUtils.e(TAG, "checkDownloadStatus start $info")
        while (true) {
            val control: Int = downloadResInfo.syncGetControl()
            val status: Int = downloadResInfo.syncGetStatus()

            if (!checkConnectivity()) {
                //网络变化
                break
            }
            if (control == DownloadConsts.Control.CONTROL_CANCEL) {
                downloadResInfo.syncSetStatus(DownloadConsts.Status.STATUS_CANCELING)
                SplitDownloadMgr.cancelDownload(info)
                break
            }
            if (control == DownloadConsts.Control.CONTROL_PAUSE) {
                downloadResInfo.syncSetStatus(DownloadConsts.Status.STATUS_PAUSING)
                SplitDownloadMgr.cancelDownload(info)
                break
            }

            if (status == DownloadConsts.Status.STATUS_SUCCESS
                    || status == DownloadConsts.Status.STATUS_UNKNOWN_ERROR
                    || info.mDownloadStatus == SplitTaskInfo.DOWNLOAD_STATUS_CANCELED

            ) {
                break
            }

            try {
                Thread.sleep(200)
            } catch (_: InterruptedException) {
            }
        }
        LogUtils.e(TAG, "checkDownloadStatus end control: ${downloadResInfo.syncGetControl()},  status: ${downloadResInfo.mStatus}  $info")
        val finalStatus = downloadResInfo.syncGetStatus()
        if (finalStatus == DownloadConsts.Status.STATUS_SUCCESS
                || finalStatus == DownloadConsts.Status.STATUS_UNKNOWN_ERROR) {
            // onDownloadSuc/onDownloadFail 回调已处理过 onDownloadSucceed/onExit，
            // 这里只需清除 isDownloadRunning 标志，不能重复调用 handleFinish()
            downloadResInfo.isDownloadRunning = false
        } else if (finalStatus != DownloadConsts.Status.STATUS_CANCELED
                && finalStatus != DownloadConsts.Status.STATUS_PAUSED) {
            // 其他未终结状态（如网络变化退出），补调 handleFinish() 做完整清理
            handleFinish()
        }
    }

    private fun checkConnectivity(): Boolean {
        val status: Int = downloadDelegate.onCurrentNetworkChanged(downloadResInfo)
        if (status != 0) {
            LogUtils.e(TAG, "executeDownload StopRequest checkConnectivity ")
            return false
        }
        return true
    }

    private fun handleProgress(info: SplitTaskInfo) {
        if (info.mDownloadStatus == SplitTaskInfo.DOWNLOAD_STATUS_RUNNING) {
            downloadResInfo.syncSetStatus(DownloadConsts.Status.STATUS_RUNNING)
        }
        downloadResInfo.mResSize = info.totalSize
        downloadResInfo.mTotalBytes = info.totalSize
        downloadResInfo.mStatus = DownloadConsts.Status.STATUS_RUNNING
        downloadResInfo.mCurrentBytes = info.currentBytes
        downloadDelegate.onProgressChanged(downloadResInfo, downloadResInfo.mCurrentBytes, 0)

    }


    fun handleFinish(isCanceled: Boolean = false) {
        var status: Int = downloadResInfo.syncGetStatus()
        LogUtils.e(TAG,
                "run finally code : $status"
        )
        if (isCanceled) {
            when (status) {
                DownloadConsts.Status.STATUS_CANCELING -> {
                    status = DownloadConsts.Status.STATUS_CANCELED
                }

                DownloadConsts.Status.STATUS_PAUSING -> {
                    status = DownloadConsts.Status.STATUS_PAUSED
                }
            }
        }
        LogUtils.e(TAG, "run finally status: $status")

        downloadResInfo.syncSetStatus(status)
        try {
            downloadDelegate.onExit(downloadResInfo, "", "", "", false, 0)
        } finally {
            // 无论 onExit 是否抛出异常，都必须清除标志，否则该任务永远无法再次启动
            downloadResInfo.isDownloadRunning = false
        }
    }

    fun getTimeFormat(start: Long): String {
        val time = (System.currentTimeMillis() - start) / 1000f
        return "耗时：${String.format("%.2f", time)}秒"
    }

    private fun refreshDownloadSuc(taskInfo: SplitTaskInfo, type: String, startTime: Long) {
        val tips = "${type}下载完成, 最大:${taskInfo?.mMaxSpeedText},平均：${taskInfo?.mSpeedText}, ${getTimeFormat(startTime)}, saveFile: ${taskInfo?.saveFile?.absolutePath}"
        LogUtils.d(SplitDownloadMgr.TAG, "onDownloadSuc: $tips")

        // 当前是下载进程，所以发送广播到主进程打点
        val tips2 = "${type}下载完成, 最大:${taskInfo?.mMaxSpeedText},平均：${taskInfo?.mSpeedText}, ${getTimeFormat(startTime)}"
        val intent = Intent("ACTION_XM_MAIN_APP_PROCESS")
        intent.putExtra("event_key", "download_avg_speed")
        intent.putExtra("avgSpeed", tips2)
        ContextUtils.getHostAppContext().sendBroadcast(intent, "com.magic.gameplf.permission.GXB_INIT")
    }


    private fun refreshDownloadFail(type: String) {
        val tips = "${type}下载失败"
        if (LogUtils.isDebug()) {
            LogUtils.d(SplitDownloadMgr.TAG, "onDownloadFail: $tips")
        }
    }

    fun composeParams(): String {
        return ("splitDownload=1" + 1)
    }

}