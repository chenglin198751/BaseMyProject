package com.qihoo.splitdownload

import android.annotation.SuppressLint
import android.text.TextUtils
import com.qihoo.appstore.utils.GlobalConfig
import com.qihoo.splitdownload.util.SplitFileUtils
import com.qihoo.utils.LogUtils
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.SocketException
import java.net.URL

/**
 * Created by caiyingyuan on 2023/10/16
 */
object SplitDownloader {
    const val REQUEST_TIME_OUT = 60 * 1000 // 设置超时时间
    const val BUFFER_SIZE: Int = 8 * 1024 // 设置缓冲区大小以提高读写效率

    private const val MAX_RETRY_COUNT = 3 // 最大重试次数
    private const val RETRY_DELAY_MS = 1000L // 重试之间的延迟时间
    private const val MAX_MERGE_RETRY_COUNT = 2 // 最大合并文件重试次数

    /**
     * 获取下载地址是否支持分片的信息
     * */
    suspend fun getDownloadRangeInfo(url:String, start: Long, end:Long = -1): JSONObject {
        return requestRangeInfo(url, mapOf(Pair("Range", "bytes=$start-" + if (end > -1) end else "")))
    }

    private fun requestRangeInfo(url: String, header: Map<String, String>): JSONObject {
        var redirects = 0
        var uri = URL(url)
        var connection: HttpURLConnection? = null
        loop@ while (true) {
            try {
                connection = (uri.openConnection() as HttpURLConnection).apply {
                    addRequestProperty("User-Agent", GlobalConfig.getDefaultUserAgent())
                    header.forEach { (key, value) ->
                        addRequestProperty(key, value)
                    }
                    requestMethod = "GET"
                    connectTimeout = REQUEST_TIME_OUT
                    readTimeout = REQUEST_TIME_OUT
                }
                when (connection.responseCode) {
                    HttpURLConnection.HTTP_MOVED_PERM,
                    HttpURLConnection.HTTP_MOVED_TEMP,
                    HttpURLConnection.HTTP_SEE_OTHER,
                    307 -> {
                        val location = connection.getHeaderField("Location")
                        if (location != null) {
                            uri = URL(location)
                            redirects++
                            if (LogUtils.isDebug()) {
                                LogUtils.d(SplitDownloadMgr.TAG, "requestRangeInfo location:$location, redirects: $redirects")
                            }
                            continue@loop
                        }
                    }
                }

                val range: String? = connection.getHeaderField("Content-Range")
                return JSONObject().apply {
                    put("range", range)
                    put("url", uri.toString())
                    put("isRedirect", redirects > 0)
                    put("redirect", redirects)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return JSONObject()
    }


    /**
     * 根据切片的大小动态切分为几片下载
     * */
    suspend fun downloadByRangeFromSize(info: SplitTaskInfo, target: File,
                                        splitLength: Long, totalSize: Long, callback: SplitDownloadMgr.IDownloadSpeedCallback
    ) {
        val splitCount = totalSize / splitLength
        downloadByRangeImpl(target, info, totalSize, splitCount.toInt(), splitLength, callback)
    }

    /**
     * 根据固定切分为几片下载
     * */
    suspend fun downloadByRangeFromCount(info: SplitTaskInfo, target: File,
                                         splitCount: Int, totalSize: Long, callback: SplitDownloadMgr.IDownloadSpeedCallback
    ) {
        val length = totalSize / splitCount
        downloadByRangeImpl(target, info, totalSize, splitCount, length, callback)
    }

    @SuppressLint("SuspiciousIndentation")
    private suspend fun downloadByRangeImpl(target: File, info: SplitTaskInfo,
                                            totalSize: Long, splitCount: Int, splitLength: Long,
                                            callback: SplitDownloadMgr.IDownloadSpeedCallback
    ) {
        val startTime = System.currentTimeMillis()
        val tempDir = SplitDownloadMgr.getTempDir(target, info)
        val tempPaths = mutableListOf<File>()
        var lastProgress: Long = -1
        var lastSpeedText: String? = null
        info.splitDownloadInfo = SplitTaskInfo.SplitDownloadInfo(splitCount, totalSize)
        if (info.currentBytes > 0) {
            val progress = info.currentBytes * 100 / totalSize
            lastProgress = progress
            CoroutineScope(Dispatchers.Main).launch {
                callback.onDownloadCallBack(info, progress.toInt())
            }
        }

        for (index in 0 until splitCount) {
            val tmpFile = File(tempDir, "${info.taskName}.incomplete_$index")
            val startIndex = index * splitLength
            // 修复Bug 3: 防止Long溢出
            val endIndex = if (index == splitCount - 1) {
                totalSize - 1
            } else {
                // 确保不会溢出
                minOf(startIndex + splitLength - 1, totalSize - 1)
            }
            info.splitDownloadInfo?.updateProgress(index, tmpFile.length())
            val isComplete = check(index, splitCount, tmpFile, totalSize, splitLength)
            val job = CoroutineScope(Dispatchers.IO).launch {
                if (!isComplete) {
                    downloadByRangeWithRetry(info, index, tmpFile, startIndex, endIndex,
                            object : SplitDownloadMgr.ISplitDownloadCallback {
                                override fun onDownloadSize(bytesCopied: Long) {
                                    info.splitDownloadInfo?.let {
                                        it.updateProgress(index, bytesCopied)
                                        val currentBytes = it.getCurrentSize
                                        info.currentBytes = currentBytes
                                        val progress = currentBytes * 100 / totalSize
                                        if (!SplitTaskInfo.isCancel(info) && (lastProgress < progress || lastSpeedText != info.mSpeedText)) {
                                            info.updateDownloadSpeed(currentBytes)
                                            lastProgress = progress
                                            lastSpeedText = info.mSpeedText
                                            CoroutineScope(Dispatchers.Main).launch {
                                                callback.onDownloadCallBack(info, progress.toInt())
                                            }
                                        }
                                    }

                                }

                                override fun onDownloadFail(e: Exception) {
                                    callback.onDownloadFail(SplitDownloadMgr.FAIL_TYPE_OTHER, e)
                                }

                                override fun onDownloadCancel() {
                                    if (info.mDownloadStatus != SplitTaskInfo.DOWNLOAD_STATUS_CANCELED) {
                                        info.mDownloadStatus = SplitTaskInfo.DOWNLOAD_STATUS_CANCELED
                                        callback.onDownloadCancel()
                                    }
                                }
                            })
                }
                // 修复Bug 1: 竞态条件，使用同步块保护
                synchronized(tempPaths) {
                    checkFinishAndMerge(index, splitCount, tmpFile, totalSize, splitLength, tempPaths, info,
                            startTime, callback, target, tempDir)
                }
            }
            if (!isComplete) {
                info.splitDownloadInfo?.addJob(job)
            }

        }

    }



    private fun checkFinishAndMerge(
            index: Int,
            splitCount: Int,
            tmpFile: File,
            totalSize: Long,
            splitLength: Long,
            tempPaths: MutableList<File>,
            info: SplitTaskInfo,
            startTime: Long,
            callback: SplitDownloadMgr.IDownloadSpeedCallback,
            target: File,
            tempDir: File
    ) {
        val isComplete = check(index, splitCount, tmpFile, totalSize, splitLength)
        if (isComplete) {
            // 使用同步块保护tempPaths的修改
            synchronized(tempPaths) {
                // 避免重复添加同一个文件
                if (!tempPaths.contains(tmpFile)) {
                    tempPaths.add(tmpFile)
                }
            }
        }
        if (LogUtils.isDebug()) {
            LogUtils.d(SplitDownloadMgr.TAG, "downloadByRange ${info.taskName},切片_$index 下载任务 " +
                    "isComplete: $isComplete, ${SplitDownloadMgr.getTimeFormat(startTime)} , path: ${tmpFile.absoluteFile}"
            )
        }

        // 使用同步块保护检查和合并逻辑
        synchronized(tempPaths) {
            // 修复Bug 1: 确保只执行一次合并操作
            if (tempPaths.size == splitCount && info.splitDownloadInfo?.isMergeing == false) {
                if (LogUtils.isDebug()) {
                    LogUtils.d(SplitDownloadMgr.TAG, "downloadByRange ${info.taskName}, 所有切片文件下载完成, ${SplitDownloadMgr.getTimeFormat(startTime)}")
                }
                info.mDownloadStatus = SplitTaskInfo.DOWNLOAD_STATUS_SUC
                callback.onSplitFileDownload()
                info.splitDownloadInfo?.isMergeing = true
                //合并文件
                val startMergeTime = System.currentTimeMillis()
                var retryCount = 0
                var mergeException: Exception? = null
                while (retryCount < MAX_MERGE_RETRY_COUNT) {
                    if (target.exists()) {
                        target.delete()
                    }
                    if (LogUtils.isDebug()) {
                        LogUtils.d(SplitDownloadMgr.TAG, "downloadByRange ${info.taskName}, 所有切片文件合并retryCount:$retryCount")
                    }
                    try {
                        mergeException = null
                        SplitFileUtils.merge(target.absolutePath, tempDir.absolutePath, splitCount)
                        callback.onMergeResult(true)
                        break
                    } catch (e: Exception) {
                        // 合并失败时添加详细日志
                        LogUtils.e(SplitDownloadMgr.TAG, "合并失败: ${e.message}")
                        SplitFileUtils.reportMergeApkFail(e.message + "")

                        if (retryCount < MAX_MERGE_RETRY_COUNT) {
                            ++retryCount
                            continue
                        } else {
                            callback.onMergeResult(false)
                            mergeException = e
                        }
                    }
                }
                if (LogUtils.isDebug()) {
                    LogUtils.d(SplitDownloadMgr.TAG, "downloadByRange ${info.taskName}, retryCount: $retryCount, 所有切片文件合并完成 isSuc: ${mergeException == null}, ${SplitDownloadMgr.getTimeFormat(startMergeTime)}")
                }
                info.splitDownloadInfo?.isMergeing = false
                if (target.exists()) {
                    CoroutineScope(Dispatchers.Main).launch {
                        if (mergeException != null) {
                            callback.onDownloadFail(SplitDownloadMgr.FAIL_TYPE_OTHER, mergeException)
                        } else {
                            callback.onDownloadSuc()
                        }
                    }
                    // 修复Bug 4: 延迟删除临时目录，确保所有操作完成
                    CoroutineScope(Dispatchers.IO).launch {
                        delay(1000) // 等待1秒确保所有操作完成
                        SplitDownloadMgr.deleteSplitTempDir(tempDir)
                    }
                }
            }
        }
    }


    private fun check(
            index: Int,
            splitCount: Int,
            tmpFile: File,
            totalSize: Long,
            length: Long
    ): Boolean {
        // 修复断点续传问题：支持部分下载的文件
        if (!tmpFile.exists()) {
            return false
        }

        // 检查文件是否可读
        if (!tmpFile.canRead()) {
            return false
        }

        val expectedSize = if (index == splitCount - 1) {
            // 最后一片的预期大小
            totalSize - length * (splitCount - 1)
        } else {
            // 其他片的预期大小
            length
        }

        // 文件大小完全匹配预期大小表示下载完成
        val isComplete = tmpFile.length() == expectedSize

        // 如果文件超出预期大小，说明存在并发追加写入导致损坏，删除后重新下载这一片
        if (tmpFile.length() > expectedSize) {
            LogUtils.e(SplitDownloadMgr.TAG, "分片文件超出预期大小，删除重下: ${tmpFile.name}, 当前大小: ${tmpFile.length()}, 预期大小: $expectedSize")
            tmpFile.delete()
            return false
        }

        // 如果文件存在但不完整，不删除文件，而是返回false让下载继续
        if (!isComplete && tmpFile.length() > 0) {
            if (LogUtils.isDebug()) {
                LogUtils.d(SplitDownloadMgr.TAG, "分片文件部分下载: ${tmpFile.name}, 当前大小: ${tmpFile.length()}, 预期大小: $expectedSize")
            }
            // 不删除文件，支持断点续传
            return false
        }

        return isComplete
    }

    private suspend fun downloadByRangeWithRetry(
            info: SplitTaskInfo,
            index: Int,
            tmpFile: File, start: Long, end: Long, callback: SplitDownloadMgr.ISplitDownloadCallback
    ) {
        var retryCount = 0
        while (retryCount < MAX_RETRY_COUNT) {
            try {
                if (LogUtils.isDebug()) {
                    LogUtils.d(SplitDownloadMgr.TAG, "downloading ${info.taskName}, $index retryCount: $retryCount startIndex: $start, endIndex: $end")
                }
                withContext(Dispatchers.IO) {
                    downloadByRangeImpl(info.downloadUrl, tmpFile, start, end, callback)
                }
                break
            } catch (e: Exception) {
                if (e is CancellationException) {
                    callback.onDownloadCancel()
                    break
                } else if (canRetry(e) && retryCount < MAX_RETRY_COUNT) { // 网络相关异常且未达到最大重试次数
                    if (LogUtils.isDebug()) {
                        LogUtils.e(SplitDownloadMgr.TAG, "分片下载异常："+ e.message)
                    }
                    // 修复断点续传问题：不要删除已下载的部分文件，支持断点续传
                    // 只有在明确文件损坏的情况下才考虑删除
                    // 注意：expectedSize是请求的总大小，但断点续传时文件可能已经部分下载
                    // 所以不能简单地比较文件大小与expectedSize
                    val delayTime = RETRY_DELAY_MS * (1 shl retryCount) //指数退避策略： 第一次1秒、第二次2秒、第三次4秒
                    if (LogUtils.isDebug()) {
                        LogUtils.d(SplitDownloadMgr.TAG, "异常重试，delayTime:$delayTime, retryCount:$retryCount ")
                    }
                    delay(delayTime) // 延迟一段时间后重试
                    ++retryCount
                    continue
                } else {
                    // 修复断点续传问题：下载失败时保留已下载的部分文件，支持断点续传
                    // 只有在明确文件损坏的情况下才删除
                    callback.onDownloadFail(e)
                    break
                }
            }
        }

    }

    private fun canRetry(e: Exception): Boolean {
        return e is SocketException ||
                e is java.net.UnknownHostException ||
                e is java.net.ConnectException ||
                e is java.net.SocketTimeoutException ||
                e is java.io.InterruptedIOException ||
                e.message?.contains("tempFile is delete") == true ||
                e.message?.contains("unexpected end of stream") == true
    }

    private suspend fun downloadByRangeImpl(
            downloadUrl: String, tmpFile: File,
            start: Long, end: Long, callback: SplitDownloadMgr.ISplitDownloadCallback
    ) {
        withContext(Dispatchers.IO) {
            // 修复断点续传问题：确保正确处理已下载的部分
            val startIndex: Long
            val fos: FileOutputStream

            if (tmpFile.exists() && tmpFile.length() > 0) {
                // 如果文件已存在且有内容，使用追加模式
                startIndex = start + tmpFile.length()
                // 验证断点续传的有效性
                if (startIndex <= end) {
                    fos = FileOutputStream(tmpFile, true) // 追加写入
                } else {
                    // 如果已下载完成，直接返回
                    callback.onDownloadSize(tmpFile.length())
                    return@withContext
                }
            } else {
                // 如果文件不存在或为空，从头开始下载
                if (!tmpFile.exists()) {
                    tmpFile.parentFile?.mkdirs()
                    tmpFile.createNewFile()
                }
                startIndex = start
                fos = FileOutputStream(tmpFile, false) // 覆盖写入
            }

            val url = URL(downloadUrl)
            val connection = url.openConnection() as HttpURLConnection
            // 设置取消监听
            coroutineContext.ensureActive()
            connection.apply {
                addRequestProperty("User-Agent", GlobalConfig.getDefaultUserAgent())
                addRequestProperty("Range", "bytes=$startIndex-$end")
                requestMethod = "GET"
                connectTimeout = REQUEST_TIME_OUT
                readTimeout = REQUEST_TIME_OUT

                if (responseCode == HttpURLConnection.HTTP_PARTIAL || responseCode == HttpURLConnection.HTTP_OK) {
                    val inputStream = inputStream ?: throw IOException("无法获取输入流")

                    fos.use { output ->
                        inputStream.use { input ->
                            val buffer = ByteArray(BUFFER_SIZE)
                            var bytesCopied: Long = tmpFile.length() // 已下载的字节数
                            while (true) {
                                if (coroutineContext.isActive.not()) {
                                    throw CancellationException("Download cancelled tmpFile: ${tmpFile.name}")
                                }
                                if (!tmpFile.exists()) {
                                    throw IOException("tempFile is delete ${tmpFile.name}")
                                }
                                val length = input.read(buffer)
                                if (length <= 0) break
                                output.write(buffer, 0, length)
                                bytesCopied += length
                                callback.onDownloadSize(bytesCopied)
                            }
                        }
                    }
                } else {
                    throw IOException("服务器响应错误：${responseMessage}")
                }
            }

        }

    }


}