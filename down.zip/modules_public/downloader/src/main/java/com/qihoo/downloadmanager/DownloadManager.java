package com.qihoo.downloadmanager;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.text.TextUtils;

import com.android.downloader.core.DownloadHttpsDomain;
import com.android.downloader.core.DownloadWork;
import com.android.downloader.core.IDownloadServiceListener;
import com.android.downloader.core.IDownloadThreadPoolFactory;
import com.qihoo.appstore.data.plugin.constant.DownloadConsts;
import com.qihoo.appstore.export.proxy.DownloadProxy;
import com.qihoo.appstore.export.proxy.download.DownloadKeys;
import com.qihoo.download.base.QHDownloadResInfo;
import com.qihoo.downloadstat.SendDownloadStatInfo;
import com.qihoo.manage.download.DownloadUtils;
import com.qihoo.product.BaseResInfo;
import com.qihoo.utils.ContextUtils;
import com.qihoo.utils.LogUtils;
import com.qihoo.utils.net.NetUtils;
import com.qihoo.utils.thread.ThreadPoolExecutorHandleCrash;
import com.qihoo360.crash.handler.CrashHandler;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * @author jinemng 这里可以开一个线程专门处理下载之前的逻辑
 */

public class DownloadManager {

    final List<DownloadListener> callbacks = new ArrayList<>();
    final List<DownloadNumChangedListener> numCallbacks = new ArrayList<>();
    final List<DownloadInterceptor> interceptors = new ArrayList<>();

    public interface DownloadListener {
        void onDownloadChanged(QHDownloadResInfo info);
    }

    public interface DownloadNumChangedListener {
        void onDownloadNumChanged(QHDownloadResInfo info);
    }

    public interface DownloadInterceptor{
        void onDownloadInterceptor(BaseResInfo resInfo);
    }

    private static final String TAG = "DownloadManager";

    private static final int MSG_INIT = 1;

    private static final int MSG_TASK_START = 2;
    private static final int MSG_TASK_PAUSE = 4;
    private static final int MSG_TASK_CANCEL = 5;

    private static volatile Handler mUpdateHandler;
    private static final Object LOCK = new Object();

    private volatile boolean hasInit = false;

    private static final Queue<Runnable> pendingTask = new LinkedList<>();
    private final DownloadWork mDownloadWorker;

    private final CheckDownloadCondition mCheckDownloadCondition;

    private static final DownloadManager instance = new DownloadManager();

    public static DownloadManager getInstance() {
        return instance;
    }


    private DownloadManager() {
        mCheckDownloadCondition = new CheckDownloadCondition(ContextUtils.getHostAppContext());
        mDownloadWorker = new DownloadWork(ContextUtils.getHostAppContext(), new buildCheckPoolFactory(), new RealDownloadPoolFactory(), new SpecialDownloadPoolFactory(), mCheckDownloadCondition);
        SendDownloadStatInfo.getInstance().initialize();
    }

    public void startDownloadById(String downloadId) {
        if (downloadId != null) {
            Bundle bundle = new Bundle();
            bundle.putString(DownloadKeys.KEY_DOWNLOAD_ID, downloadId);
            DownloadProxy.startDownloadById(bundle);
        }
    }

    public QHDownloadResInfo getDownloadResInfo(String downloadId) {
        return getDownloadResInfo(downloadId, false, 1);
    }

    public QHDownloadResInfo getDownloadInfoByPackageName(String pkgName) {
        return getDownloadResInfo(pkgName, true, 2);
    }

    public QHDownloadResInfo getDownloadInfoByUrl(String url) {
        return getDownloadResInfo(url, true, 3);
    }

    private QHDownloadResInfo getDownloadResInfo(String downloadId, boolean isPkgName, int type) {
        Bundle bundle = new Bundle();
        bundle.putBoolean(DownloadKeys.KEY_IS_DOWNLOAD_ID, !isPkgName);
        bundle.putInt(DownloadKeys.KEY_DOWNLOAD_ID_TYPE, type);
        Bundle result = DownloadProxy.getDownloadResInfo(downloadId, bundle);
        QHDownloadResInfo info = new QHDownloadResInfo();
        if (info.parse(result)) {
            return info;
        }
        return null;
    }

    public void startDowload(BaseResInfo baseResInfo, Bundle bundle) {
        if (baseResInfo != null) {
            if (interceptors != null && interceptors.size() > 0) {
                for (DownloadInterceptor interceptor : interceptors) {
                    interceptor.onDownloadInterceptor(baseResInfo);
                }
            }
            DownloadProxy.startDownload(DownloadUtils.createBundle(baseResInfo, bundle));
        }
    }

    public void startDownload(QHDownloadResInfo info, boolean bUIFront) {
        DownloadWork.isMainActivityFront = bUIFront;
        runOrPending(new DownloadOperatingTask(MSG_TASK_START, info, mDownloadWorker));
        DownloadHttpsDomain.getInstance().init();
    }

    public void pauseDownload(String downloadId, Bundle bundle) {
        DownloadProxy.pauseDownload(downloadId, bundle);
    }

    public void pauseDownload(QHDownloadResInfo info) {

        runOrPending(new DownloadOperatingTask(MSG_TASK_PAUSE, info,
                mDownloadWorker));
    }

    public void cancelDownload(QHDownloadResInfo info) {
        runOrPending(new DownloadOperatingTask(MSG_TASK_CANCEL, info,
                mDownloadWorker));
    }

    public void cancelDownload(String downloadId, Bundle bundle) {
        DownloadProxy.cancelDownload(downloadId, bundle);
    }

    private void runOrPending(DownloadOperatingTask task) {
        if (hasInit) {
            task.run();
        } else {
            synchronized (pendingTask) {
                if (hasInit) {
                    task.run();
                } else {
                    pendingTask.add(task);
                }
            }
        }
    }

    public void registerDownloadObserver(long processId, IDownloadServiceListener listener) {
        mDownloadWorker.registerDownloadObserver(processId, listener);
    }

    public void unRegisterDownloadObserver(long processId, IDownloadServiceListener listener) {
        mDownloadWorker.unRegisterDownloadObserver(processId, listener);
    }

    public void init() {
        if (!hasInit) {
            checkUpdateHandler();
            synchronized (LOCK) {
                if (mUpdateHandler != null) {
                    mUpdateHandler.removeMessages(MSG_INIT);
                    mUpdateHandler.obtainMessage(MSG_INIT, this).sendToTarget();
                }
            }
        }
    }

    private static void checkUpdateHandler() {
        if (mUpdateHandler == null) {
            synchronized (LOCK) {
                if (mUpdateHandler == null) {
                    HandlerThread mUpdateThread = new HandlerThread(
                            "DefaultDownloadManager-UpdateThread");
                    mUpdateThread.start();
                    mUpdateHandler = new Handler(mUpdateThread.getLooper(), mUpdateCallback);
                }
            }
        }
    }

    private static void stopUpdateThread() {
        synchronized (LOCK) {
            if (mUpdateHandler != null) {
                mUpdateHandler.getLooper().quit();
                mUpdateHandler = null;
            }
        }
    }

    private final static Handler.Callback mUpdateCallback = new Handler.Callback() {

        @Override
        public boolean handleMessage(Message msg) {
            int what = msg.what;
            Object obj = msg.obj;

            switch (what) {
                case MSG_INIT: {
                    if (obj instanceof DownloadManager) {
                        DownloadManager downloadManager = (DownloadManager) obj;
                        synchronized (pendingTask) {
                            for (Runnable runnable : pendingTask) {
                                runnable.run();
                            }
                        }
                        downloadManager.hasInit = true;
                    }
                }
                break;
                default:
                    break;
            }
            return true;
        }
    };


    public void addListener(DownloadListener listener) {
        if (listener != null && !callbacks.contains(listener)) {
            callbacks.add(listener);
            if (callbacks.size() + numCallbacks.size() == 1) {
                DownloadProxy.addDownloadListener();
            }
        }
    }

    public void removeListener(DownloadListener listener) {
        callbacks.remove(listener);
        if (callbacks.isEmpty() && numCallbacks.isEmpty()) {
            DownloadProxy.removeDownloadListener();
        }
    }

    public void addNumChangedListener(DownloadNumChangedListener listener) {
        if (listener != null && !numCallbacks.contains(listener)) {
            numCallbacks.add(listener);
            if (callbacks.size() + numCallbacks.size() == 1) {
                DownloadProxy.addDownloadListener();
            }
        }
    }

    public void openApp(String pkgName, String statInfo) {
        Bundle bundle = new Bundle();
        if (!TextUtils.isEmpty(statInfo)) {
            bundle.putString(DownloadProxy.KEY_LAUNCH_APP_STAT_INFO, statInfo);
        }
        openApp(pkgName, bundle);
    }

    public Bundle openApp(String pkgName, Bundle bundle) {
        return DownloadProxy.openApp(pkgName, bundle);
    }

    private class DownloadOperatingTask implements Runnable {

        private final int taskType;
        private QHDownloadResInfo info;
        private final DownloadWork downloadWorker;

        public DownloadOperatingTask(int taskType, String resId,
                                     DownloadWork downloadWorker) {
            this.taskType = taskType;
            this.downloadWorker = downloadWorker;
        }

        public DownloadOperatingTask(int taskType, QHDownloadResInfo info,
                                     DownloadWork downloadWorker) {
            this.taskType = taskType;
            this.info = info;
            this.downloadWorker = downloadWorker;
        }

        @Override
        public void run() {
            if (info == null) {
                CrashHandler.getInstance().tryCatch(new RuntimeException(), "DownloadManger run() ");
                return;
            }

            QHDownloadResInfo info_ui_thread = downloadWorker.mapDownloadResInfo.get(info.id);
            switch (taskType) {
                case MSG_TASK_START: {
                    if (info_ui_thread == null || info_ui_thread.weakRefDownloadInfo == null) {
                        info_ui_thread = new QHDownloadResInfo();
                        info_ui_thread.setVales(info, false);
                        downloadWorker.mapDownloadResInfo.put(info_ui_thread.id, info_ui_thread);
                        downloadWorker.startPreDownload(info_ui_thread);
                    } else {
                        // 任务已在内存中运行，保留内存中的实时进度，避免用 IPC 快照覆盖
                        long keepCurrentBytes = info_ui_thread.mCurrentBytes;
                        long keepTotalBytes = info_ui_thread.mTotalBytes;
                        info_ui_thread.setVales(info, false);
                        if (keepCurrentBytes > info_ui_thread.mCurrentBytes) {
                            info_ui_thread.mCurrentBytes = keepCurrentBytes;
                        }
                        if (keepTotalBytes > info_ui_thread.mTotalBytes) {
                            info_ui_thread.mTotalBytes = keepTotalBytes;
                        }
                        QHDownloadResInfo info_work_thread = info_ui_thread.weakRefDownloadInfo.get();
                        if (info_work_thread == null || info_work_thread.mSubmittedTask == null || info_work_thread.mSubmittedTask.isDone()) {
                            LogUtils.d(TAG, "MSG_TASK_START 已经启动后，又启动一次");
                            downloadWorker.startPreDownload(info_ui_thread);
                        } else {
                            LogUtils.e(TAG, "MSG_TASK_START error status " + info_ui_thread.mStatus);
                        }
                    }
                }
                break;

                case MSG_TASK_PAUSE: {
                    if (info_ui_thread == null) {
                        // 任务不在内存，用传入 info 构造（不存在可被覆盖的实时进度）
                        downloadWorker.mapDownloadResInfo.put(info.id, info);
                        info_ui_thread = new QHDownloadResInfo();
                        info_ui_thread.setVales(info, false);
                        QHDownloadResInfo info_work_thread = new QHDownloadResInfo();
                        info_work_thread.setVales(info_ui_thread, false);
                        info_ui_thread.weakRefDownloadInfo = new WeakReference<>(info_work_thread);
                        info_work_thread.weakRefDownloadInfo = new WeakReference<>(info_ui_thread);
                    }
                    // info_ui_thread != null 时直接 pause，不用 IPC 快照覆盖内存实时进度
                    downloadWorker.pauseDownload(info_ui_thread);
                }
                break;

                case MSG_TASK_CANCEL: {
                    if (info_ui_thread == null) {
                        downloadWorker.mapDownloadResInfo.put(info.id, info);
                        info_ui_thread = new QHDownloadResInfo();
                        info_ui_thread.setVales(info, false);
                        QHDownloadResInfo info_work_thread = new QHDownloadResInfo();
                        info_work_thread.setVales(info_ui_thread, false);
                        info_ui_thread.weakRefDownloadInfo = new WeakReference<>(info_work_thread);
                        info_work_thread.weakRefDownloadInfo = new WeakReference<>(info_ui_thread);
                    }
                    downloadWorker.cancelDownload(info_ui_thread);
                }
                break;
                default:
                    break;
            }
        }
    }

    public void onDestroy() {
        stopUpdateThread();
        mDownloadWorker.onDestroy();
    }

    private static class buildCheckPoolFactory implements IDownloadThreadPoolFactory {

        private static final ThreadFactory sThreadFactory = new ThreadFactory() {
            private final AtomicInteger mCount = new AtomicInteger(1);

            @SuppressWarnings("NullableProblems")
            public Thread newThread(Runnable r) {
                return new Thread(r, "predownload#"
                        + mCount.getAndIncrement());
            }
        };

        public ThreadPoolExecutor buildDownloadExecutor() {
            int keepAliveTime = 10;
            if (LogUtils.isDebug()) {
                keepAliveTime = 30;
            }
            final ThreadPoolExecutor executor = new ThreadPoolExecutorHandleCrash(1, 1,
                    keepAliveTime, TimeUnit.SECONDS,
                    new LinkedBlockingQueue<Runnable>(), sThreadFactory);
            executor.allowCoreThreadTimeOut(true);

            return executor;
        }

    }

    private static class RealDownloadPoolFactory implements IDownloadThreadPoolFactory {

        private static final ThreadFactory sThreadFactory = new ThreadFactory() {
            private final AtomicInteger mCount = new AtomicInteger(1);

            @SuppressWarnings("NullableProblems")
            public Thread newThread(Runnable r) {
                return new Thread(r, "downloadthread#"
                        + mCount.getAndIncrement());
            }
        };

        public ThreadPoolExecutor buildDownloadExecutor() {
            int cpuCount;// = DeviceUtils.getCpuCount();
//            int coreThreadCount = cpuCount + 1;
            int maxCoreThreadCount;// coreThreadCount * 2 + 1;
            int keepAliveTime = 10;

            // 先写死，和手机助手默认值保持一致，以后版本优化。
            cpuCount = 2;
            maxCoreThreadCount = 2;

            final ThreadPoolExecutor executor = new ThreadPoolExecutorHandleCrash(
                    cpuCount, maxCoreThreadCount, keepAliveTime,
                    TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(),
                    sThreadFactory);
            executor.allowCoreThreadTimeOut(true);
            return executor;
        }
    }

    private static class SpecialDownloadPoolFactory implements IDownloadThreadPoolFactory {

        private static final ThreadFactory sThreadFactory = new ThreadFactory() {
            private final AtomicInteger mCount = new AtomicInteger(1);

            @SuppressWarnings("NullableProblems")
            public Thread newThread(Runnable r) {
                return new Thread(r, "specialdownload#"
                        + mCount.getAndIncrement());
            }
        };

        public ThreadPoolExecutor buildDownloadExecutor() {
            int keepAliveTime = 10;
            if (LogUtils.isDebug()) {
                keepAliveTime = 60;
            }
            final ThreadPoolExecutor executor = new ThreadPoolExecutorHandleCrash(2, 2,
                    keepAliveTime, TimeUnit.SECONDS,
                    new LinkedBlockingQueue<Runnable>(), sThreadFactory);
            executor.allowCoreThreadTimeOut(true);

            return executor;
        }


    }


    public void onCheckCondition(boolean bOK, final QHDownloadResInfo info, int count) {
        int status = getStatus(count, info);
        if (DownloadConsts.Condition.CHECK_NET == count) {
            if (DownloadConsts.Status.STATUS_NOT_START == status) {
                LogUtils.safeCheck(false);
                bOK = true;
            }
        }
        mDownloadWorker.onCheckCondition(bOK, info, count, status);
    }

    public void setMainActivityFront(boolean bFront) {
        LogUtils.d("P2pDownLoadThread_DownloadManager", "setMainActivityFront " + bFront);
        DownloadWork.isMainActivityFront = bFront;
    }

    private int getStatus(int count, QHDownloadResInfo info) {
        if (DownloadConsts.Condition.CHECK_NET == count) {
            if (NetUtils.isNetworkConnected()) {
                if (NetUtils.isFreeWifi(true)) {
                    if (info != null) {
                        info.mErrorCode = 0;
                    }
                    return DownloadConsts.Status.STATUS_NOT_START;
                } else {
                    if (info != null) {
                        info.mErrorCode = DownloadConsts.ErrCode.ERR_DATA_NET_WHEN_CONNECT;
                    }
                    return DownloadConsts.Status.STATUS_ERROR_IN_DATA_NET;
                }
            } else {
                if (info != null) {
                    info.mErrorCode = DownloadConsts.ErrCode.ERR_NO_ACTIVE_NET_WHEN_CONNECT;
                }
                return DownloadConsts.Status.STATUS_NETWORK_NOT_OK;
            }
        } else if (DownloadConsts.Condition.CHECK_DISK == count) {
            if (info != null) {
                info.mErrorCode = DownloadConsts.ErrCode.ERR_NO_SPACE_FOR_DATA_NET_WHEN_CONNECT;
            }
            return DownloadConsts.Status.STATUS_INSUFFICIENT_SPACE_ERROR;
        }

        LogUtils.safeCheck(false);
        return 0;
    }

    public void onNoConnection() {
        mDownloadWorker.onNoConnection();
    }


}
