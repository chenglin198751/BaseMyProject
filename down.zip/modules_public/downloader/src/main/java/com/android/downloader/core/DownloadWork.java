package com.android.downloader.core;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.android.downloader.core.PreDownloadThread.IPreDownloadCallback;
import com.qihoo.appstore.data.plugin.constant.DownloadConsts;
import com.qihoo.appstore.data.plugin.info.DownloadResInfo;
import com.qihoo.download.DownloadThreadProxy;
import com.qihoo.download.base.QHDownloadResInfo;
import com.qihoo.downloadmanager.DownloadNetWatcher;
import com.qihoo.downloadmanager.DownloadServiceWatcher;
import com.qihoo.utils.ContextUtils;
import com.qihoo.utils.LogUtils;
import com.qihoo.utils.net.NetConsts;
import com.qihoo.utils.net.NetUtils;
import com.qihoo.utils.thread.ThreadUtils;

import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author jinmeng 默认的下载核心中转层逻辑
 *         <p/>
 *         取消任务的处理： cancelDownload 在UI线程先通知主界面更新界面，然后删除自己。
 *         如果没有下载，则删除文件；如果有下载，则通过下载线程的回调删除下载线程中的map元素
 */
public class DownloadWork {
    private final String TAG = "DownloadWork";
    private final String TAG2 = "DownloadWork";

    private DownloadScanner mScanner;

    public static boolean isMainActivityFront = true;

    private volatile ThreadPoolExecutor mPreDownloadExecutor;
    private volatile ThreadPoolExecutor mDownloadExecutor;
    private volatile ThreadPoolExecutor mSpecialDownloadExecutor;
    private volatile ThreadPoolExecutor mViewDownloadExecutor; //view 级别的插件需要快速下载，不和原来的插件用一个通道

    private final IDownloadThreadPoolFactory preDownloadPoolFactory;
    private final IDownloadThreadPoolFactory downloadPoolFactory;
    private final IDownloadThreadPoolFactory specialDownloadPoolFactory;

    private final DownloadObservable observable = new DownloadObservable();

    public final HashMap<String, QHDownloadResInfo> mapDownloadResInfo = new HashMap<>();
    private final HashMap<String, QHDownloadResInfo> map_download_info_work_thread = new HashMap<>();

    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    private final long mMainThreadId = ThreadUtils.getMainThreadId();

    private final IPreDownloadCallback mPreDownloadCallback;
    private final int mCheckConditionCount;
    private CountDownLatch mCountDownLatch;

    private static DownloadServiceWatcher watcher;

    public Map<String, QHDownloadResInfo> getDownloads() {
        return Collections.unmodifiableMap(mapDownloadResInfo);
    }

    public void registerDownloadObserver(long processId, IDownloadServiceListener observer) {
        observable.addObserver(processId, observer);
    }

    public void unRegisterDownloadObserver(long processId, IDownloadServiceListener observer) {
        observable.deleteObserver(processId, observer);
    }

    public void onReadyToStartDownload(final DownloadResInfo info) {
        if (Thread.currentThread().getId() != mMainThreadId) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    notifyDownloadStatusImp((QHDownloadResInfo) info, false);
                }
            });
        }
    }


    public void notifyStatusChanged(final DownloadResInfo info, final boolean phoneCalling2G) {

        if (Thread.currentThread().getId() != mMainThreadId) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    notifyDownloadStatusImp((QHDownloadResInfo) info, phoneCalling2G);
                }
            });
        }
    }

    public void notifyProgressChanged(final DownloadResInfo info, final boolean isProgressChanged) {

        if (Thread.currentThread().getId() != mMainThreadId) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    notifyDownloadStatusImp((QHDownloadResInfo) info, false);
                }
            });
        } else {
            notifyDownloadStatusImp((QHDownloadResInfo) info, false);
        }
    }

    private void notifyDownloadStatusImp(QHDownloadResInfo info, boolean phoneCalling2G) {

        QHDownloadResInfo info_ui_thread = null;
        if (info.weakRefDownloadInfo != null) {
            info_ui_thread = info.weakRefDownloadInfo.get();
        }

        if (info_ui_thread != null) {
            if (phoneCalling2G) {
                info_ui_thread.updateDownloadSpeed(info_ui_thread.mCurrentBytes, true);
                observable.notifyObservers(info_ui_thread);
                LogUtils.d(TAG, "notifyDownloadStatusImp phoneCalling2G: " + true);
                return;
            }

            if (info_ui_thread.isDownloadInfoChanged(info)) {
                info_ui_thread.setVales(info, true);
                if (needNotify(info_ui_thread)) {
                    info_ui_thread.updateDownloadSpeed(info_ui_thread.mCurrentBytes, false);
                    observable.notifyObservers(info_ui_thread);
                }

                if (DownloadConsts.Status.STATUS_CANCELED == info.mStatus) {
                    cancelDownloadImp(info);
                }
                if (DownloadConsts.isStatusCompleted(info.mStatus)) {
                    synchronized (DownloadWork.class) {
                        if (mScanner != null) {
                            mScanner.requestScan(info);
                        }
                    }
                }
            }
        }
    }

    private boolean needNotify(QHDownloadResInfo info_ui_thread) {
        boolean ret = true;

        if (info_ui_thread.mStatus == DownloadConsts.Status.STATUS_RUNNING) {
            long curTime = System.currentTimeMillis();
            if (info_ui_thread.mLastUpdateUITime == 0) {
                info_ui_thread.mLastUpdateUITime = curTime;
            } else {
                if (info_ui_thread.mLastUpdateUITime + 100 > curTime) {
                    ret = false;
                } else
                    info_ui_thread.mLastUpdateUITime = curTime;
            }

        }

        return ret;
    }

    private void notifyDownloadStatusUIThread(QHDownloadResInfo info) {
        if (info == null || info.weakRefDownloadInfo == null) {
            LogUtils.safeCheck(false);
            return;
        }

        QHDownloadResInfo info_ui_thread = info.weakRefDownloadInfo.get();
        if (info_ui_thread != null) {
            info_ui_thread.setVales(info, false);

            info_ui_thread.updateDownloadSpeed(info_ui_thread.mCurrentBytes, false);
            observable.notifyObservers(info_ui_thread);
        }
    }

    public DownloadWork(Context context,
                        IDownloadThreadPoolFactory preDownloadPoolFactory,
                        IDownloadThreadPoolFactory downloadPoolFactory,
                        IDownloadThreadPoolFactory specialDownloadPoolFactory,
                        IPreDownloadCallback preDownloadCallback) {
        Context appCtx = context.getApplicationContext();

        this.mPreDownloadCallback = preDownloadCallback;

        mCheckConditionCount = preDownloadCallback.getCount();

        synchronized (DownloadWork.class) {
            if (mScanner == null) {
                mScanner = new DownloadScanner(appCtx);
            }
        }

        this.preDownloadPoolFactory = preDownloadPoolFactory;
        this.downloadPoolFactory = downloadPoolFactory;


        this.specialDownloadPoolFactory = specialDownloadPoolFactory;

        watcher = new DownloadServiceWatcher();
        watcher.Moniter(this);

        new DownloadNetWatcher(this).netMonitor();

    }

    private void checkPreDownloadThreadPool() {
        if (mPreDownloadExecutor == null) {
            synchronized (this) {
                if (mPreDownloadExecutor == null) {
                    mPreDownloadExecutor = preDownloadPoolFactory.buildDownloadExecutor();
                }
            }
        }
    }

    private void checkDownloadThreadPool() {
        if (mDownloadExecutor == null) {
            synchronized (this) {
                if (mDownloadExecutor == null) {
                    mDownloadExecutor = downloadPoolFactory.buildDownloadExecutor();
                }
            }
        }
    }

    private void checkSpecialDownloadThreadPool() {
        if (mSpecialDownloadExecutor == null) {
            synchronized (this) {
                if (mSpecialDownloadExecutor == null) {
                    mSpecialDownloadExecutor = specialDownloadPoolFactory.buildDownloadExecutor();
                }
            }
        }

        if (mViewDownloadExecutor == null) {
            synchronized (this) {
                if (mViewDownloadExecutor == null) {
                    mViewDownloadExecutor = specialDownloadPoolFactory.buildDownloadExecutor();
                }
            }
        }
    }

    public void startPreDownload(QHDownloadResInfo info_ui_thread) {

        LogUtils.e(TAG, "startPreDownload " + info_ui_thread.mStatus + " " + info_ui_thread.downloadUrl);

        info_ui_thread.isUIThread = true;

        checkPreDownloadThreadPool();

        QHDownloadResInfo info_work_thread;

        if (info_ui_thread.weakRefDownloadInfo == null || info_ui_thread.weakRefDownloadInfo.get() == null) {
            info_work_thread = new QHDownloadResInfo();
            info_work_thread.setVales(info_ui_thread, true);
            info_work_thread.isUIThread = false;
            info_ui_thread.weakRefDownloadInfo = new WeakReference<>(info_work_thread);
            info_work_thread.weakRefDownloadInfo = new WeakReference<>(info_ui_thread);
        } else {
            info_work_thread = info_ui_thread.weakRefDownloadInfo.get();
            info_work_thread.setVales(info_ui_thread, false);
        }

        if (info_ui_thread.mStatus == DownloadConsts.Status.STATUS_PAUSED) {
            info_work_thread.mStatus = DownloadConsts.Status.STATUS_CONTINUE_PENDING;
            info_ui_thread.mStatus = DownloadConsts.Status.STATUS_CONTINUE_PENDING;
        } else {
            info_work_thread.mStatus = DownloadConsts.Status.STATUS_PENDING;
            info_ui_thread.mStatus = DownloadConsts.Status.STATUS_PENDING;
        }

        notifyDownloadStatusUIThread(info_work_thread);


        synchronized (map_download_info_work_thread) {
            map_download_info_work_thread.put(info_work_thread.id,
                    info_work_thread);
        }

        startPreDownloadImp(info_ui_thread, mPreDownloadExecutor);
    }

    public class StartDownloadRunnable implements Runnable {
        private final QHDownloadResInfo info_work_thread;

        public StartDownloadRunnable(QHDownloadResInfo info_work_thread) {
            this.info_work_thread = info_work_thread;
        }

        @Override
        public void run() {
            if (info_work_thread != null && info_work_thread.weakRefDownloadInfo != null) {
                notifyDownloadStatusUIThread(info_work_thread);
            }
        }
    }

    private void startDownload(QHDownloadResInfo info_ui_thread) {

        LogUtils.e(TAG, "startDownload begin " + info_ui_thread.mStatus + " " + info_ui_thread.id);

        checkDownloadThreadPool();
        checkSpecialDownloadThreadPool();

        if (LogUtils.isDebug()) {
            if (info_ui_thread.weakRefDownloadInfo == null || info_ui_thread.weakRefDownloadInfo.get() == null) {
                throw new RuntimeException("startDownload weakRefDownloadInfo null " + info_ui_thread.resPackageName + " " + info_ui_thread.mStatus + " " + info_ui_thread.weakRefDownloadInfo);
            }
        }

        QHDownloadResInfo info_work_thread = info_ui_thread.weakRefDownloadInfo.get();
        if (info_work_thread != null && info_work_thread.mStatus != DownloadConsts.Status.STATUS_PAUSING && info_work_thread.mStatus != DownloadConsts.Status.STATUS_CANCELING
                && (info_work_thread.mSubmittedTask == null || info_work_thread.mSubmittedTask.isDone())) {

            info_work_thread.setVales(info_ui_thread, false);

            info_work_thread.syncSetControl(DownloadConsts.Control.CONTROL_RUN);


            startDownloadIfReady(info_work_thread, mDownloadExecutor, mSpecialDownloadExecutor, mViewDownloadExecutor);

            LogUtils.e(TAG, "startDownload imp " + info_work_thread.mStatus + " " + info_work_thread.hashCode() + " " + info_work_thread.resPackageName);
            mMainHandler.postDelayed(new StartDownloadRunnable(info_work_thread), 100);
        }
    }

    private void setStatusWhenPause(boolean isPausing, QHDownloadResInfo info_work_thread) {
        if (info_work_thread.mSubmittedTask == null || info_work_thread.mSubmittedTask.isDone()) {
            LogUtils.d(TAG, "pauseDownload A task done " + info_work_thread.mStatus);
            info_work_thread.syncSetStatus(DownloadConsts.Status.STATUS_PAUSED);
        } else {
            if (info_work_thread.mStatus == DownloadConsts.Status.STATUS_PENDING || info_work_thread.mStatus == DownloadConsts.Status.STATUS_CONTINUE_PENDING) {
                info_work_thread.mSubmittedTask.cancel(true);
                LogUtils.d(TAG, "cancelDownload B task done " + info_work_thread.mSubmittedTask.isCancelled() + " " + info_work_thread.mSubmittedTask.isDone());
                info_work_thread.mStatus = DownloadConsts.Status.STATUS_PAUSED;
            }

            if (!isPausing) {
                if (info_work_thread.mStatus != DownloadConsts.Status.STATUS_PAUSED && info_work_thread.mStatus != DownloadConsts.Status.STATUS_PAUSING) {
                    info_work_thread.syncSetStatus(DownloadConsts.Status.STATUS_PAUSING);
                }
            }
        }
    }

    public void pauseDownload(QHDownloadResInfo info_ui_thread) {
        // 如果用户连续点击两次可能为空
        LogUtils.safeCheck(info_ui_thread != null && info_ui_thread.weakRefDownloadInfo != null && info_ui_thread.weakRefDownloadInfo.get() != null);
        if (info_ui_thread == null) {
            return;
        }

        LogUtils.d(TAG, "pauseDownload " + info_ui_thread.resName + " " + info_ui_thread.resPackageName + " " + info_ui_thread.downloadUrl);
        if (info_ui_thread.weakRefDownloadInfo == null || info_ui_thread.weakRefDownloadInfo.get() == null) {
            observable.notifyObservers(info_ui_thread);
            return;
        }
        QHDownloadResInfo info_work_thread = info_ui_thread.weakRefDownloadInfo.get();
        if (info_work_thread != null) {
            // 保护工作线程的实时进度，避免用 UI 线程的旧值覆盖
            long keepCurrentBytes = info_work_thread.mCurrentBytes;
            long keepTotalBytes = info_work_thread.mTotalBytes;
            info_work_thread.setVales(info_ui_thread, true);
            if (keepCurrentBytes > info_work_thread.mCurrentBytes) {
                info_work_thread.mCurrentBytes = keepCurrentBytes;
            }
            if (keepTotalBytes > info_work_thread.mTotalBytes) {
                info_work_thread.mTotalBytes = keepTotalBytes;
            }
        }
        checkDownloadThreadPool();
        checkSpecialDownloadThreadPool();

        if (info_work_thread != null) {
            if (info_work_thread.mSubmittedTask == null) {
                LogUtils.e(TAG, "pauseDownload begin " + info_work_thread.mStatus + " " + info_work_thread.resPackageName);
            } else {
                LogUtils.e(TAG, "pauseDownload begin " + info_work_thread.mStatus + " " + info_work_thread.mSubmittedTask.hashCode() + " " + info_work_thread.mSubmittedTask.isDone() + " " + info_work_thread.resPackageName);
            }

            info_work_thread.syncSetControl(DownloadConsts.Control.CONTROL_PAUSE);
            if (info_work_thread.mStatus == DownloadConsts.Status.STATUS_PENDING) {
                setStatusWhenPause(false, info_work_thread);
            } else if (info_work_thread.mStatus == DownloadConsts.Status.STATUS_RUNNING) {
                setStatusWhenPause(false, info_work_thread);
            } else if (info_work_thread.mStatus == DownloadConsts.Status.STATUS_PAUSING) {
                setStatusWhenPause(true, info_work_thread);
            } else if (info_work_thread.mStatus == DownloadConsts.Status.STATUS_CANCELING) {
                setStatusWhenPause(false, info_work_thread);
            } else { //
                setStatusWhenPause(false, info_work_thread);
            }

            if (info_work_thread.mSubmittedTask == null) {
                LogUtils.e(TAG, "pauseDownload end " + info_work_thread.mStatus);
            } else {
                LogUtils.e(TAG, "pauseDownload end " + info_work_thread.mStatus + " " + info_work_thread.mSubmittedTask.isDone());
            }

            notifyDownloadStatusUIThread(info_work_thread);
        }
    }

    private void setStatusWhenCancel(boolean isCanceling, QHDownloadResInfo info_work_thread, int preState) {
        if (info_work_thread.mSubmittedTask == null || info_work_thread.mSubmittedTask.isDone()) {
            LogUtils.d(TAG, "cancelDownload A task done " + preState);
            info_work_thread.syncSetStatus(DownloadConsts.Status.STATUS_CANCELED);
            notifyDownloadStatusUIThread(info_work_thread);
            cancelDownloadImp(info_work_thread);
            DownloadThreadProxy.onCanceled(info_work_thread.mTaskID);
        } else {
            if (info_work_thread.mStatus == DownloadConsts.Status.STATUS_PENDING || info_work_thread.mStatus == DownloadConsts.Status.STATUS_CONTINUE_PENDING) {
                info_work_thread.mSubmittedTask.cancel(true);
                LogUtils.d(TAG, "cancelDownload B task done " + info_work_thread.mSubmittedTask.isCancelled() + " " + info_work_thread.mSubmittedTask.isDone());
                info_work_thread.mStatus = DownloadConsts.Status.STATUS_CANCELED;
            }

            if (!isCanceling) {
                LogUtils.d(TAG, "cancelDownload B task done " + preState);
                if (info_work_thread.mStatus != DownloadConsts.Status.STATUS_CANCELED && info_work_thread.mStatus != DownloadConsts.Status.STATUS_CANCELING) {
                    info_work_thread.syncSetStatus(DownloadConsts.Status.STATUS_CANCELING);
                }
            }
            notifyDownloadStatusUIThread(info_work_thread);
        }
    }


    public void cancelDownload(QHDownloadResInfo info_ui_thread) {
        LogUtils.e(TAG, "cancelDownload " + info_ui_thread.mStatus + " " + info_ui_thread.resName + " " + info_ui_thread.downloadUrl);
        checkDownloadThreadPool();
        checkSpecialDownloadThreadPool();
//        if (LogUtils.isDebug()) {
//            if (info_ui_thread.weakRefDownloadInfo == null || info_ui_thread.weakRefDownloadInfo.get() == null) {
//                throw new RuntimeException("cancelDownload weakRefDownloadInfo null");
//            }
//        }

        if (info_ui_thread.weakRefDownloadInfo == null) {
            if (LogUtils.isDebug()) {
                LogUtils.e(TAG, "cancelDownload exception ", new RuntimeException());
            }
            info_ui_thread.mStatus = DownloadConsts.Status.STATUS_CANCELED;
            observable.notifyObservers(info_ui_thread);
            return;
        }

        QHDownloadResInfo info_work_thread = info_ui_thread.weakRefDownloadInfo.get();
        if (info_work_thread != null) {

            if (info_work_thread.mSubmittedTask == null) {
                LogUtils.e(TAG, "cancelDownload " + info_work_thread.mStatus + " mSubmittedTask: null");
            } else {
                LogUtils.e(TAG, "cancelDownload " + info_work_thread.mStatus + " " + info_work_thread.mSubmittedTask + " " + info_work_thread.mSubmittedTask.isDone());
            }

            int preState = info_work_thread.mStatus;

            info_work_thread.syncSetControl(DownloadConsts.Control.CONTROL_CANCEL);
            if (preState == DownloadConsts.Status.STATUS_RUNNING || preState == DownloadConsts.Status.STATUS_PAUSING) {
                setStatusWhenCancel(false, info_work_thread, preState);
            } else if (preState == DownloadConsts.Status.STATUS_PENDING) {
                setStatusWhenCancel(false, info_work_thread, preState);
            } else if (preState == DownloadConsts.Status.STATUS_CANCELING) {
                setStatusWhenCancel(true, info_work_thread, preState);
            } else {
                setStatusWhenCancel(false, info_work_thread, preState);
            }
        }
    }

    private void cancelDownloadImp(QHDownloadResInfo info_work_thread) {
        synchronized (map_download_info_work_thread) {
            info_work_thread.weakRefDownloadInfo = null;
            mapDownloadResInfo.remove(info_work_thread.id);
        }
    }

    public void onDestroy() {
        observable.deleteObservers();
        synchronized (DownloadWork.class) {
            mScanner.shutdown();
            mScanner = null;
        }
    }


    // ////////////////////////////////////////////////////////// ////////////////////////////////////////////////////////

    private void startPreDownloadImp(QHDownloadResInfo info_ui_thread, ExecutorService executor) {
        synchronized (this) {
            Future<?> task = null;
            try {
                task = executor.submit(new PreDownloadThread(ContextUtils.getHostAppContext(), info_ui_thread, this));
                LogUtils.d(TAG, "startPreDownloadImp " + task + " isShutdown: " + executor.isShutdown() + " isTerminated: " + executor.isTerminated());
            } catch (RejectedExecutionException e) {
                if (task != null) {
                    Log.e(TAG, "startPreDownloadImp " + task + " isShutdown: " + executor.isShutdown() + " isTerminated: " + executor.isTerminated());
                } else {
                    Log.e(TAG, "startPreDownloadImp task: null");
                }
                e.printStackTrace();
            }
            if (task == null) {
                Log.e(TAG, "startPreDownloadImp task: null " + " isShutdown: " + executor.isShutdown() + " isTerminated: " + executor.isTerminated());
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        }
    }

    private void startDownloadIfReady(QHDownloadResInfo info_work_thread,
                                      ExecutorService downloadExecutor,
                                      ExecutorService specialDownloadExecutor,
                                      ExecutorService viewDownloadExecutor) {

        synchronized (this) {
            final boolean isActive = info_work_thread.mSubmittedTask != null && !info_work_thread.mSubmittedTask.isDone();
            // 双重检查：isDone() 为 true 后，旧任务的 finally 块可能还未执行完
            // isDownloadRunning 由 finally 块最后一行清除，确保不会并发启动两个下载任务
            if (!isActive && !info_work_thread.isDownloadRunning) {
                info_work_thread.isDownloadRunning = true;
                CommonDownloadDelegate delegate = new CommonDownloadDelegate(this);
                Runnable task = new DownloadThreadProxy(ContextUtils.getHostAppContext(), info_work_thread, delegate);
                if (info_work_thread.downloadInSpecialTask == 1) {
                    info_work_thread.mSubmittedTask = specialDownloadExecutor.submit(task);
                } else if (info_work_thread.downloadInSpecialTask == 2) {
                    info_work_thread.mSubmittedTask = viewDownloadExecutor.submit(task);
                } else {
                    info_work_thread.mSubmittedTask = downloadExecutor.submit(task);
                }
                LogUtils.d(TAG, "startDownloadIfReady ok mSubmittedTask = " + info_work_thread.mSubmittedTask.hashCode() + " " + task.hashCode() + " " + info_work_thread.resPackageName + " " + info_work_thread.downloadInSpecialTask);
            } else {
                LogUtils.d(TAG, "startDownloadIfReady skip: isActive=" + isActive + " isDownloadRunning=" + info_work_thread.isDownloadRunning + " " + info_work_thread.resPackageName);
            }
        }
    }

    public boolean startScanIfReady(QHDownloadResInfo info,
                                    DownloadScanner scanner) {
        synchronized (this) {
            final boolean isReady = shouldScanFile(info);
            if (isReady) {
                scanner.requestScan(info);
            }
            return isReady;
        }
    }

    private boolean shouldScanFile(QHDownloadResInfo info) {
        return DownloadConsts.isStatusSuccess(info.mStatus);
    }

    //////////////////////////////////////////////////
    public class CheckConditionRunnable implements Runnable {
        private final int count;
        private final QHDownloadResInfo info;

        CheckConditionRunnable(QHDownloadResInfo info, int count) {
            this.info = info;
            this.count = count;
        }

        @Override
        public void run() {
            observable.checkConditionByUser(info, count, info.mResSize);
        }
    }

    private void startDownloadInMainThread(final QHDownloadResInfo info) {
        if (info == null) {
            return;
        }

        if (info.notVisible > 0 && info.isUpdateSilentTask == 1) {
            if (!NetUtils.isFreeWifi(false) || NetUtils.getNetType() != NetConsts.NET_TYPE_WIFI) {
                LogUtils.safeCheck(false);
                return;
            }
            if (!com.qihoo.utils.PowerStateUtils.isPowerStateOK(TAG)) {
                return;
            }
        }

        if (Thread.currentThread().getId() != mMainThreadId) {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    LogUtils.d(TAG, "checkCondition() startDownload " + info.nCheckCondition + " " + mCheckConditionCount);
                    startDownload(info);
                }
            });

        } else {
            startDownload(info);
        }
    }

    public void checkCondition(final QHDownloadResInfo info_ui_thread) {
        info_ui_thread.nCheckCondition = 0;
        for (int nIndex = 0; nIndex < mCheckConditionCount; ++nIndex) {
            if (!mPreDownloadCallback.checkCondition(info_ui_thread, nIndex)) {
                LogUtils.safeCheck(mCountDownLatch == null);
                mCountDownLatch = new CountDownLatch(1);
                LogUtils.d(TAG2, "lock  checkCondition() wait threadid: " + ThreadUtils.getCurThreadId() + " lock: " + mCountDownLatch.hashCode() + " " + mCountDownLatch.getCount() + " xxxxxx " + info_ui_thread.resName + " " + mMainThreadId);
                if (Thread.currentThread().getId() != mMainThreadId) {
                    try {
                        mMainHandler.post(new CheckConditionRunnable(info_ui_thread, nIndex));
                    } catch (Throwable e) {
                        LogUtils.d(TAG2, "lock  checkCondition() wait threadid: uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu  ", e);
                    }
                } else {
                    LogUtils.d(TAG2, "lock  checkCondition() wait threadid: rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr");
                    LogUtils.safeCheck(false);
                }
                try {
                    LogUtils.d(TAG2, "lock  checkCondition() wait threadid: mCountDownLatch.await(); ");
                    LogUtils.d(TAG2, "lock  checkCondition() wait threadid: mCountDownLatch.await(); " + mCountDownLatch);
                    LogUtils.d(TAG2, "lock  checkCondition() wait threadid: mCountDownLatch.await() 2; ");
                    mCountDownLatch.await();
                    mCountDownLatch = null;
                    LogUtils.d(TAG2, "lock  checkCondition() wait threadid: mCountDownLatch.await() mCountDownLatch = null; ");
                } catch (Exception ex) {
                    LogUtils.d(TAG2, ex.toString());
                    LogUtils.d(TAG2, ex.getMessage());
                    ex.printStackTrace();
                    LogUtils.d(TAG2, "lock  checkCondition() wait threadid: wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww ");
                    ex.printStackTrace();
                }
            } else {
                ++info_ui_thread.nCheckCondition;
            }
        }

        LogUtils.d(TAG2, "checkCondition() wait result " + " threadid: " + ThreadUtils.getCurThreadId() + " " + info_ui_thread.resName);

        if (info_ui_thread.nCheckCondition == mCheckConditionCount) {
            startDownloadInMainThread(info_ui_thread);
        } else {
            QHDownloadResInfo info_work_thread = info_ui_thread.weakRefDownloadInfo.get();
            if (info_work_thread != null) {
                info_work_thread.setVales(info_ui_thread, false);
                notifyDownloadStatusUIThread(info_work_thread);
            }
        }
    }

    public void onCheckCondition(boolean bOK, QHDownloadResInfo info, int count, int status) {
        QHDownloadResInfo info_ui_thread = null;
        if (info != null) {
            info_ui_thread = mapDownloadResInfo.get(info.id);
        }
        LogUtils.safeCheck(info_ui_thread != null);
        if (info_ui_thread == null) {
            countDownLock();
            return;
        }

        LogUtils.d(TAG, "onCheckCondition " + bOK + " " + status);

        info_ui_thread.setVales(info, false);

        if (bOK) {
            if (count == DownloadConsts.Condition.CHECK_NET) {
                LogUtils.d(TAG2, "onCheckCondition OK " + " sucess " + ThreadUtils.getCurThreadId());
                info_ui_thread.canUseDataNet = true;
            }
            ++info_ui_thread.nCheckCondition;
        } else {
            LogUtils.d(TAG2, "onCheckCondition Fail " + " fail ");
            info_ui_thread.mStatus = status;
        }
        countDownLock();
    }

    private void countDownLock() {
        if (mCountDownLatch != null) {
            LogUtils.d(TAG2, "lock countDownLock（） " + " threadid: " + ThreadUtils.getCurThreadId() + " lock: " + mCountDownLatch.hashCode() + " lockCount: " + mCountDownLatch.getCount());
            mCountDownLatch.countDown();
        } else {
            LogUtils.safeCheck(false);
        }
    }

    public void notifyNoConnction() {
        observable.notifyNoConnction();
    }

    public void onNoConnection() {
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                watcher.onNoConnection();
            }
        });
    }

}
