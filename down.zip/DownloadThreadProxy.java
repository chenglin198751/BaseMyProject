package com.qihoo.download;

import android.content.Context;
import android.text.TextUtils;

import com.qihoo.appstore.data.plugin.constant.DownloadConsts;
import com.qihoo.appstore.data.plugin.info.DownloadResInfo;
import com.qihoo.downloadservice.QHVCSdkConsts;
import com.qihoo.httpdownload.HttpDownloadThread;
import com.qihoo.p2pdownload.P2pDownLoadThread;
import com.qihoo.p2pdownload.P2pEngine;
import com.qihoo.appstore.data.plugin.constant.Consts;
import com.qihoo.splitdownload.SplitDownloadThread;
import com.qihoo.utils.LogUtils;
import com.qihoo.utils.NetUrlUtils;
import com.qihoo.videocloud.api.QHVCNet;
import com.qihoo360.common.notification.AppStoreNotificationSharedPref;

import net.qihoo.videocloud.LocalServerPlugin;

import java.util.HashMap;
import java.util.Map;

public class DownloadThreadProxy implements Runnable {

    private static final String TAG = "P2pDownLoadThread_DownloadThreadProxy";

    private final Context mContext;

    private final DownloadResInfo mDownloadResInfo;
    private final IDownloadDelegate mDownloadDelegate;

    private final DownloadStrategy mDownloadStrategy = new DownloadStrategy();
    private int lastDownloadBusiness = DownloadConsts.DownloadBusiness.INIT;

    public DownloadThreadProxy(Context context, DownloadResInfo info,
                               IDownloadDelegate downloadDelegate) {
        mContext = context;
        mDownloadResInfo = info;
        mDownloadDelegate = downloadDelegate;
    }

    @Override
    public void run() {
        try {
            _run();
        } catch (Exception e) {
            LogUtils.e(TAG, "run catch ", e);
            throw e;
        } finally {
            mDownloadResInfo.isDownloadRunning = false;
        }

        LogUtils.d(TAG, "run() End ....................... " + hashCode() + " " + mDownloadResInfo.downloadUrl);
    }

    public static void onCanceled(int taskID) {
        if (taskID != -1 && P2pEngine.mEngine != null) {
            P2pEngine.mEngine.DeleteTask(taskID, false);
        }
    }

    private boolean isQHVCNetPluginValid() {
        final LocalServerPlugin liveCloudPlugin = LocalServerPlugin.getInstance();
        if (liveCloudPlugin != null && liveCloudPlugin.isPluginValid()) {
            return true;
        } else {
            return false;
        }
    }

    private boolean isResSupportToUseP2p() {
        if (LogUtils.isDebug()) {
            LogUtils.d(TAG, "isResSupportToUseP2p:resType " + mDownloadResInfo.resType + ",isPluginTask()," + mDownloadResInfo.isPluginTask() + ",downloadUrl," + mDownloadResInfo.downloadUrl);
        }
        //插件下载地址根据云控开关决定是否启用p2p，默认启用
        if (mDownloadResInfo.isPluginTask()) {
            return AppStoreNotificationSharedPref.getInstance().getBoolean(QHVCSdkConsts.KEY_PLUGIN_P2P_DOWNLOAD, true);
        }
        //排除掉差量地址，外部下载地址，以及非apk下载地址
        return TextUtils.isEmpty(mDownloadResInfo.diffUrl)
                && (NetUrlUtils.isApkUrl(mDownloadResInfo.downloadUrl) || mDownloadResInfo.resType == Consts.ResType.RESTYPE_APK)
                && mDownloadResInfo.isCdnUrl;
    }

    private void _run() {

        if (!mDownloadDelegate.onStart(mDownloadResInfo)) {
            return;
        }

        mDownloadResInfo.getSequenceId(false);

        mDownloadResInfo.mDownloadTimes = 0;

        while (++(mDownloadResInfo.mDownloadTimes) <= 2) {
            LogUtils.d(TAG, "[_run]download times : " + mDownloadResInfo.mDownloadTimes +
                    " ,useHttps:" + mDownloadResInfo.useHttps + " ,reDownload:" + mDownloadResInfo.reDownload +
                    " ,http:" + mDownloadResInfo.downloadUrl + " ,https:" + mDownloadResInfo.httpsDownloadUrl);
            LogUtils.d(TAG, AppStoreNotificationSharedPref.getInstance().getBoolean(QHVCSdkConsts.KEY_P2P_DOWNLOAD, true) + ",isP2POpen)");
            mDownloadDelegate.onInitDownloadParam(mDownloadResInfo);
            mDownloadResInfo.mStatus = DownloadConsts.Status.STATUS_RUNNING;
            mDownloadResInfo.startDownloadTime = System.currentTimeMillis();
            mDownloadDelegate.onInitDownloadInfo(mDownloadResInfo);
            doP2pStrategy();//执行获取代理地址的逻辑
            mDownloadResInfo.downloadEngineType = mDownloadStrategy.chooseDownloadType(mDownloadResInfo);
            //判断是否支持分片下载
            if (mDownloadDelegate.isSupportSplit(mDownloadResInfo)) {
                mDownloadResInfo.downloadEngineType = DownloadConsts.DownloadType.split_down;
            }

            if (mDownloadResInfo.mDownloadTimes == 2 && lastDownloadBusiness != DownloadConsts.DownloadBusiness.QHVC) {
                P2pEngine.deleteTempFiles(mDownloadResInfo.savePath);
                LogUtils.d(TAG, "_run: AfterDownlaodStat" + "lastDownloadBusiness," + lastDownloadBusiness);
            }


            if (DownloadConsts.Status.STATUS_ERROR_FILE_NOT_EXIST == mDownloadResInfo.mStatus ||
                    DownloadConsts.Status.STATUS_ERROR_FILE_NOT_EXIST_ == mDownloadResInfo.mStatus) {
                mDownloadDelegate.getRetryPath(mDownloadResInfo);
            }

            LogUtils.d(TAG, "while() begin " + mDownloadResInfo.downloadEngineType + " " + mDownloadResInfo.getRealDownloadUrl() + " times: " + mDownloadResInfo.mDownloadTimes);

//            mDownloadResInfo.downloadEngineType = DownloadConsts.DownloadType.okHttp;
            if (mDownloadResInfo.downloadEngineType == DownloadConsts.DownloadType.split_down) {
                SplitDownloadThread mainWorker = new SplitDownloadThread(mContext, mDownloadResInfo, mDownloadDelegate);
                mainWorker.run();

            } else if (mDownloadResInfo.downloadEngineType == DownloadConsts.DownloadType.p2p) {
                P2pDownLoadThread mainWorker = new P2pDownLoadThread(mContext);
                mainWorker.initialize(mDownloadResInfo, mDownloadDelegate);
                mainWorker.run();
            } else if (mDownloadResInfo.downloadEngineType == DownloadConsts.DownloadType.http) {
                try {
                    HttpDownloadThread mainWorker = new HttpDownloadThread(mContext, mDownloadResInfo, mDownloadDelegate);
                    mainWorker.run();
                }catch (Throwable e){
                    if (LogUtils.isDebug()){
                        LogUtils.e(TAG,"",e);
                    }
                }
            } else {
                LogUtils.safeCheck(false);
            }
            LogUtils.d(TAG, "mainWorker.run() end " + mDownloadResInfo.mStatus + " " + mDownloadResInfo.mErrorCode + " times: " + mDownloadResInfo.mDownloadTimes);
            if (DownloadConsts.isDownloadError(mDownloadResInfo.mStatus) && mDownloadResInfo.currentDownloadBusiness == DownloadConsts.DownloadBusiness.QHVC) {
                //使用视频云的p2p下载失败之后会尝试强制使用原先助手的下载模块进行下载
                if (LogUtils.isDebug()) {
                    LogUtils.d(TAG, "_run qhvc_p2p end error, need reDownload ours ");
                }
                //以下几种错误要删除临时文件，因为mDownloadResInfo.mDownloadTimes = 2删除的时候把DownloadConsts.DownloadBusiness.QHVC排除在外了
                switch (mDownloadResInfo.mStatus) {
                    case DownloadConsts.Status.STATUS_ERROR_FILE_NOT_EXIST:
                    case DownloadConsts.Status.STATUS_ERROR_FILE_NOT_EXIST_:
                    case DownloadConsts.Status.NEW_DL_TASK_RENAME_FILE_FAILED:
                        P2pEngine.deleteTempFiles(mDownloadResInfo.savePath);
                        if (LogUtils.isDebug()) {
                            LogUtils.d(TAG, "deleteTempFiles: " + "DownloadBusiness.QHVC + 1");
                        }
                    default:
                }
                mDownloadDelegate.onP2pExtraStat(mDownloadResInfo, DownloadConsts.TYPE_P2P_DOWNLOAD_ERROR_AND_RETRY);
            } else if (DownloadConsts.Status.STATUS_ERROR_FILE_NOT_EXIST == mDownloadResInfo.mStatus ||
                    DownloadConsts.Status.STATUS_ERROR_FILE_NOT_EXIST_ == mDownloadResInfo.mStatus) {
                P2pEngine.deleteTempFiles(mDownloadResInfo.savePath);
                mDownloadResInfo.usingTFWModel = false;
            } else if (mDownloadResInfo.mStatus == DownloadConsts.Status.NEW_DL_TASK_RENAME_FILE_FAILED) {
                // 如果是重命名文件失败了，应该是临时文件不存在了，这种情况强制进行重试
                LogUtils.d(TAG, "_run end error, need reDownload http ");
                mDownloadResInfo.usingTFWModel = false;
            } else if (mDownloadResInfo.mStatus == DownloadConsts.Status.STATUS_ERROR_IN_DATA_NET || mDownloadResInfo.mStatus == DownloadConsts.Status.STATUS_NETWORK_NOT_OK) {
                break;
            } else if (mDownloadStrategy.RestartDownloadWithTFW(mDownloadResInfo, mDownloadResInfo.downloadEngineType == DownloadConsts.DownloadType.p2p)) {
                mDownloadResInfo.usingTFWModel = true;
                LogUtils.d(TAG, "_run end error, need reDownload tfw branch 1 ");
            } else if (!mDownloadResInfo.usingTFWModel) {
                if (DownloadConsts.Status.STATUS_NEED_TFW == mDownloadResInfo.mStatus) {
                    mDownloadResInfo.usingTFWModel = true;
                    LogUtils.d(TAG, "_run end error, need reDownload tfw branch 2 ");
                } else if (DownloadConsts.Status.STATUS_FILE_ERROR == mDownloadResInfo.mStatus) {
                    break;
                } else {
                    break;
                }
            } else {
                break;
            }
            LogUtils.d(TAG, "download while() end " + mDownloadResInfo.downloadEngineType + " " + mDownloadResInfo.downloadUrl + " times: " + mDownloadResInfo.mDownloadTimes);
        } // end while

        LogUtils.d(TAG, "_run end ");
        if (LocalServerPlugin.getInstance().isPluginValid() && isQHVCNetPluginValid()) {
            if (mDownloadResInfo.mDownloadTimes == 1 && !TextUtils.isEmpty(mDownloadResInfo.p2pStrategyUrl)) {
                QHVCNet.cancelP2pTask(mDownloadResInfo.p2pStrategyUrl);
                if (LogUtils.isDebug()) {
                    LogUtils.d(TAG, "QHVCNet.cancelP2pTask,DownloadTimes:" + mDownloadResInfo.mDownloadTimes);
                }
            }
        }
    } // end _run()

    private void doP2pStrategy() {
        lastDownloadBusiness = mDownloadResInfo.currentDownloadBusiness;
        if (lastDownloadBusiness == DownloadConsts.DownloadBusiness.QHVC && mDownloadResInfo.mDownloadTimes == 2
                && !TextUtils.isEmpty(mDownloadResInfo.p2pStrategyUrl)) {
            QHVCNet.cancelP2pTask(mDownloadResInfo.p2pStrategyUrl);
            LogUtils.d(TAG, "QHVCNet.cancelP2pTask,DownloadTimes:" + mDownloadResInfo.mDownloadTimes);
        }
        LogUtils.d(TAG, "QHVCNet" + isResSupportToUseP2p() + "," + LocalServerPlugin.getInstance().isPluginValid() + "," + isQHVCNetPluginValid());
        if (mDownloadResInfo.mDownloadTimes < 2 && isResSupportToUseP2p()
                && AppStoreNotificationSharedPref.getInstance().getBoolean(QHVCSdkConsts.KEY_P2P_DOWNLOAD, true)
                && LocalServerPlugin.getInstance().isPluginValid()
                && isQHVCNetPluginValid()) {
            String rid = mDownloadResInfo.fileMd5 + mDownloadResInfo.mResSize + mDownloadResInfo.signMd5;//资源的唯一标识，用来缓存用
            Map<String, Object> getPlayUrlOptions = new HashMap<>();
            getPlayUrlOptions.put(QHVCNet.QHVC_NET_KEY_OPTION_OPEN_LOCALSERVER, Boolean.FALSE);
            getPlayUrlOptions.put(QHVCNet.QHVC_NET_KEY_OPTION_P2P_TASK_MODE, QHVCNet.QHVC_NET_P2P_TASK_MODE_DOWNLAOD);
            if (mDownloadResInfo.reDownload && (!TextUtils.isEmpty(mDownloadResInfo.httpsDownloadUrl))) {
                mDownloadResInfo.p2pStrategyUrl = QHVCNet.getPlayUrl(rid, mDownloadResInfo.httpsDownloadUrl, getPlayUrlOptions);
            } else {
                mDownloadResInfo.p2pStrategyUrl = QHVCNet.getPlayUrl(rid, mDownloadResInfo.downloadUrl, getPlayUrlOptions);
            }
            mDownloadResInfo.currentDownloadBusiness = DownloadConsts.DownloadBusiness.QHVC;
        } else {
            mDownloadResInfo.currentDownloadBusiness = DownloadConsts.DownloadBusiness.INIT;
            mDownloadResInfo.p2pStrategyUrl = null;
        }
    }
}