package com.qihoo.httpdownload;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.PowerManager;
import android.os.Process;
import android.text.TextUtils;

import com.qihoo.appstore.data.plugin.constant.DownloadConsts;
import com.qihoo.appstore.data.plugin.info.DownloadResInfo;
import com.qihoo.appstore.utils.GlobalConfig;
import com.qihoo.download.IDownloadDelegate;
import com.qihoo.download.base.StopRequest;
import com.qihoo.utils.ArrayMap;
import com.qihoo.utils.ContextUtils;
import com.qihoo.utils.FileUtils;
import com.qihoo.utils.LogUtils;
import com.qihoo.utils.PathUtils;
import com.qihoo.utils.SDCardUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import okhttp3.ConnectionSpec;
import okhttp3.Dns;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.internal.Util;

import static android.text.format.DateUtils.SECOND_IN_MILLIS;
import static java.net.HttpURLConnection.HTTP_INTERNAL_ERROR;
import static java.net.HttpURLConnection.HTTP_MOVED_PERM;
import static java.net.HttpURLConnection.HTTP_MOVED_TEMP;
import static java.net.HttpURLConnection.HTTP_OK;
import static java.net.HttpURLConnection.HTTP_PARTIAL;
import static java.net.HttpURLConnection.HTTP_PRECON_FAILED;
import static java.net.HttpURLConnection.HTTP_SEE_OTHER;
import static java.net.HttpURLConnection.HTTP_UNAVAILABLE;

public class HttpDownloadThread implements Runnable {

    private final static String TAG = "P2pDownLoadThread_HttpDownloadThread";
    private static final int DEFAULT_TIMEOUT = (int) (30 * SECOND_IN_MILLIS);
    private static final int HTTP_TEMP_REDIRECT = 307;
    private static final int HTTP_REQUESTED_RANGE_NOT_SATISFIABLE = 416;
    private final BaseDownloadResource mInfoDelta;
    private final DownloadResInfo mInfo;
    private final Context mAppContext;
    private IDownloadDelegate mDownloadDelegate = null;
    private final DownloadSpeedTracker mSpeedTracker = new DownloadSpeedTracker();

    private String mUseUrl = null;

    public HttpDownloadThread(Context context, DownloadResInfo info, IDownloadDelegate downloadDelegate) {
        mInfoDelta = new BaseDownloadResource(info);
        mAppContext = context.getApplicationContext();
        mInfo = info;

        mDownloadDelegate = downloadDelegate;
    }

    private static long getHeaderFieldLong(String valueStr, long defaultValue) {
        try {
            return Long.parseLong(valueStr);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    @SuppressLint("InvalidWakeLockTag")
    @Override
    public void run() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);

        PowerManager.WakeLock wakeLock = null;
        final PowerManager pm = (PowerManager) mAppContext
                .getSystemService(Context.POWER_SERVICE);

        try {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    DownloadConsts.HTTP_DOWNLOAD_THREAD_TAG);
//            wakeLock.acquire();

            mInfoDelta.savePath = mInfo.savePath;

            LogUtils.e(TAG, "run before executeDownload() " + mInfo.savePath);

            executeDownload();

            LogUtils.e(TAG, "run after executeDownload()");

            mDownloadDelegate.onDownloadSucceed(mInfo, "", "", "", false, false, 0, false);
            mInfoDelta.mStatus = DownloadConsts.Status.STATUS_SUCCESS;
            mInfo.mStatus = mInfoDelta.mStatus;
            reportAvgSpeed();

            if (mInfoDelta.mTotalBytes == -1) {
                mInfoDelta.mTotalBytes = mInfoDelta.mCurrentBytes;
            }

        } catch (StopRequest e) {

            LogUtils.e(TAG, "run catch (StopRequest e) " + e.getFinalStatus() + " " + e.toString());

            mInfoDelta.mStatus = e.getFinalStatus();
            mInfoDelta.mErrorMsg = e.getMessage();
            mInfoDelta.mNetCode = e.getNetCode();

        } catch (Throwable t) {

            LogUtils.e(TAG, "run catch (Throwable t) " + t.toString());

            mInfoDelta.mStatus = DownloadConsts.Status.STATUS_UNKNOWN_ERROR;
            mInfoDelta.mErrorMsg = t.toString();

        } finally {

            if (wakeLock != null && wakeLock.isHeld()) {
                try {
                    wakeLock.release();
                } catch (Exception ignored) {
                }
            }

            int status = mInfo.syncGetStatus();

            LogUtils.e(TAG, "run finally code : " + status + " exception code: " + mInfoDelta.mStatus);

            if (status == DownloadConsts.Status.STATUS_CANCELING) {
                status = DownloadConsts.Status.STATUS_CANCELED;
            } else if (status == DownloadConsts.Status.STATUS_PAUSING) {
                status = DownloadConsts.Status.STATUS_PAUSED;
            } else {
                status = mInfoDelta.mStatus;
            }
            mInfo.mNetCode = mInfoDelta.mNetCode;

            LogUtils.e(TAG, "run finally status: " + status);

            if (status == DownloadConsts.Status.STATUS_PAUSED
                    || status == DownloadConsts.Status.STATUS_CANCELED) {
                reportAvgSpeed();
            }

            mInfo.syncSetStatus(status);

            try {
                mDownloadDelegate.onExit(mInfo, "", "", "", false, 0);
            } finally {
                // do nothing
            }
        }
    }

    private static final int MAX_RETRY_ON_TIMEOUT = 3;
    // 总超时 15 分钟，兜底防止 read 假死（服务端缓慢滴入字节不触发 readTimeout）
    private static final long CALL_TIMEOUT_MS = 15 * 60 * 1000L;

    private void executeDownload() throws StopRequest {
        long totalSize = mInfo.mTotalBytes;
        if (mInfo.mTotalBytes <= 0 && mInfo.showSize > 0) {
            totalSize = mInfo.showSize;
        }
        long correctBytes = verifyResuming(mInfo.savePath, mInfo.mCurrentBytes, totalSize);
        boolean resuming = correctBytes != 0;
        LogUtils.d(TAG, "mInfo.savePath, mInfo.mCurrentBytes, mInfo.mTotalBytes,resuming "
                + mInfo.savePath + "," + mInfo.mCurrentBytes + "," + mInfo.mTotalBytes + ", totalSize:" + totalSize + "," + resuming);
        mInfo.mCurrentBytes = correctBytes;
        mInfoDelta.mCurrentBytes = mInfo.mCurrentBytes;
        mDownloadDelegate.onStartDownload(mInfo);

        URL url;
        try {
            LogUtils.d(TAG, "[executeDownload]reDownload:" + mInfo.reDownload + " ,DownloadTimes:" + mInfo.mDownloadTimes + " ,https url:" + mInfo.httpsDownloadUrl);
            if (!TextUtils.isEmpty(mInfo.p2pStrategyUrl) && (mInfo.mDownloadTimes < 2)) {
                url = new URL(mInfo.p2pStrategyUrl);
            } else if ((mInfo.reDownload || (mInfo.mDownloadTimes > 1)) && !TextUtils.isEmpty(mInfo.httpsDownloadUrl)) {
                url = new URL(mInfo.httpsDownloadUrl);
                // 切到 HTTPS 地址后清空 ETag，避免与原 HTTP 域名的 ETag 不一致导致 412
                mInfoDelta.mETag = null;
                mInfo.mETag = null;
                LogUtils.d(TAG, "[executeDownload]use https, reDownload:" + mInfo.reDownload + " ,DownloadTimes:" + mInfo.mDownloadTimes + " ,url:" + mInfo.httpsDownloadUrl);
            } else {
                url = new URL(mInfo.downloadUrl);
                LogUtils.d(TAG, "[executeDownload]reDownload:" + mInfo.reDownload + " ,DownloadTimes:" + mInfo.mDownloadTimes + " ,url:" + mInfo.httpsDownloadUrl);
            }
            mUseUrl = url.toString();
        } catch (MalformedURLException e) {
            LogUtils.e(TAG, "executeDownload new URL MalformedURLException " + e.toString());
            throw new StopRequest(DownloadConsts.Status.STATUS_BAD_REQUEST, e);
        }

        int redirectionCount = 0;
        int retryCount = 0;

        while (redirectionCount + retryCount < DownloadConsts.MAX_REDIRECTS) {
            try {
                checkConnectivity();
                OkHttpClient.Builder builder = new OkHttpClient().newBuilder()
                        .readTimeout(DEFAULT_TIMEOUT, TimeUnit.MILLISECONDS)
                        .writeTimeout(DEFAULT_TIMEOUT, TimeUnit.MILLISECONDS)
                        .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.MILLISECONDS)
                        .callTimeout(CALL_TIMEOUT_MS, TimeUnit.MILLISECONDS);
                builder.dns(new Dns() {
                    @Override
                    public List<InetAddress> lookup(String hostname) throws UnknownHostException {
                        if ("127.0.0.1".equals(hostname)) {
                            // 这个几乎全部走 IPV4流量了
                            return new ArrayList<>();
                        }
                        if (TextUtils.isEmpty(hostname)) {
                            return Dns.SYSTEM.lookup(hostname);
                        } else {
                            try {
                                List<InetAddress> inetAddressList = new ArrayList<>();
                                InetAddress[] inetAddresses = InetAddress.getAllByName(hostname);
                                int v4Count = 0;
                                int v6Count = 0;
                                for (InetAddress inetAddress : inetAddresses) {
                                    LogUtils.d(TAG, "OkHttpClient IPv6Utils InetAddress " + inetAddress.toString());
                                    if (inetAddress instanceof Inet6Address) {
                                        v6Count++;
                                        inetAddressList.add(inetAddressList.size() - v4Count, inetAddress);
                                    } else {
                                        v4Count++;
                                        inetAddressList.add(inetAddress);
                                    }
                                }
                                LogUtils.d(TAG, "OkHttpClient IPv6Utils Dns lookup result: " + inetAddressList.toString());
                                return inetAddressList;
                            } catch (Exception ex) {
                                return Dns.SYSTEM.lookup(hostname);
                            }
                        }
                    }
                });
                if (Build.VERSION.SDK_INT < 21) {
                    builder.connectionSpecs(Util.immutableList(ConnectionSpec.COMPATIBLE_TLS, ConnectionSpec.CLEARTEXT));
                }
                OkHttpClient okHttpClient = builder.build();
                Request.Builder requestBuilder = new Request.Builder().url(mUseUrl);
                addRequestHeaders(requestBuilder, resuming);

                LogUtils.e(TAG, "executeDownload begin " + url.toString());
                Response response = okHttpClient.newCall(requestBuilder.build()).execute();
                LogUtils.e(TAG, "OkHttpClient responseCode " + response.code());

                final int responseCode = response.code();
                LogUtils.e(TAG, "executeDownload responseCode " + responseCode + " redirect:" + redirectionCount + " retry:" + retryCount);
                try {
                    switch (responseCode) {

                        case HTTP_OK:
                            if (resuming) {
                                // 服务端不支持断点续传，返回了完整内容，需要删除旧文件并重置进度
                                File file = new File(mInfo.savePath);
                                if (file.exists() && file.length() > 0) {
                                    long fileLength = file.length();
                                    if (!file.delete()) {
                                        LogUtils.e(TAG, "不支持断点续传 删除老的下载文件失败, savePath:" + mInfo.savePath);
                                        throw new StopRequest(DownloadConsts.Status.STATUS_FILE_ERROR,
                                                "Failed to delete old file for non-resumable download");
                                    }
                                    LogUtils.e(TAG, "不支持断点续传 删除老的下载文件, savePath:" + mInfo.savePath + ", fileLength: " + fileLength);
                                }
                                // 服务端返回 200 说明是全量重传，必须重置进度计数器
                                mInfoDelta.mCurrentBytes = 0;
                                mInfo.mCurrentBytes = 0;
                                resuming = false;
                            }
                            parseOkHeaders(response);
                            try {
                                transferData(response);
                            } catch (StopRequest e) {
                                if (isRetryableTimeout(e) && retryCount < MAX_RETRY_ON_TIMEOUT) {
                                    retryCount++;
                                    LogUtils.e(TAG, "SocketTimeoutException 重试下载 retry:" + retryCount
                                            + ", savePath:" + mInfo.savePath + ", downloadUrl: " + mInfo.downloadUrl);
                                    refreshResumingState();
                                    resuming = mInfoDelta.mCurrentBytes > 0;
                                    continue;
                                }
                                throw e;
                            }
                            return;

                        case HTTP_PARTIAL:
                            if (!resuming) {
                                LogUtils.e(TAG, "executeDownload StopRequest HTTP_PARTIAL resuming ");
                                throw new StopRequest(
                                        DownloadConsts.Status.STATUS_CANNOT_RESUME,
                                        "Expected OK, but received partial");
                            }
                            try {
                                transferData(response);
                            } catch (StopRequest e) {
                                if (isRetryableTimeout(e) && retryCount < MAX_RETRY_ON_TIMEOUT) {
                                    retryCount++;
                                    LogUtils.e(TAG, "HTTP_PARTIAL SocketTimeoutException 重试下载 retry:" + retryCount
                                            + ", savePath:" + mInfo.savePath + ", downloadUrl: " + mInfo.downloadUrl);
                                    refreshResumingState();
                                    resuming = mInfoDelta.mCurrentBytes > 0;
                                    continue;
                                }
                                throw e;
                            }
                            return;

                        case HTTP_MOVED_PERM:
                        case HTTP_MOVED_TEMP:
                        case HTTP_SEE_OTHER:
                        case HTTP_TEMP_REDIRECT:
                            final String location = response.header("Location");

                            url = new URL(url, location);
                            // 同步更新本次请求实际使用的 URL，否则下一轮还会请求旧地址
                            mUseUrl = url.toString();
                            mDownloadDelegate.onRedirect(location);

                            if (responseCode == HTTP_MOVED_PERM) {
                                mInfoDelta.downloadUrl = url.toString();
                                mInfo.downloadUrl = mInfoDelta.downloadUrl;
                            }
                            redirectionCount++;
                            continue;

                        case HTTP_PRECON_FAILED:
                            LogUtils.e(TAG, "executeDownload StopRequest HTTP_PRECON_FAILED ");
                            throw new StopRequest(
                                    DownloadConsts.Status.STATUS_CANNOT_RESUME,
                                    "Precondition failed");

                        case HTTP_REQUESTED_RANGE_NOT_SATISFIABLE:
                            LogUtils.e(TAG, "executeDownload StopRequest HTTP_REQUESTED_RANGE_NOT_SATISFIABLE ");
                            throw new StopRequest(
                                    DownloadConsts.Status.STATUS_CANNOT_RESUME,
                                    "Requested range not satisfiable");

                        case HTTP_UNAVAILABLE:
                            LogUtils.e(TAG, "executeDownload StopRequest HTTP_UNAVAILABLE ");
                            throw new StopRequest(HTTP_UNAVAILABLE,
                                    response.message());

                        case HTTP_INTERNAL_ERROR:
                            LogUtils.e(TAG, "executeDownload StopRequest HTTP_INTERNAL_ERROR ");
                            throw new StopRequest(HTTP_INTERNAL_ERROR,
                                    response.message());

                        default:
                            LogUtils.e(TAG, "executeDownload StopRequest default ");
                            StopRequest.throwUnhandledHttpError(responseCode, response.message());
                    }
                } catch (StopRequest stopRequest) {
                    stopRequest.setNetCode(responseCode);
                    throw stopRequest;
                }

            } catch (IOException e) {
                if (e instanceof ProtocolException
                        && e.getMessage().startsWith("Unexpected status line")) {
                    LogUtils.e(TAG, "executeDownload StopRequest ProtocolException ");
                    throw new StopRequest(
                            DownloadConsts.Status.STATUS_UNHANDLED_HTTP_CODE, e);
                } else {
                    LogUtils.e(TAG, "executeDownload StopRequest STATUS_HTTP_DATA_ERROR ");
                    throw new StopRequest(
                            DownloadConsts.Status.STATUS_HTTP_DATA_ERROR, e);
                }

            } finally {

            }
        }

        LogUtils.e(TAG, "executeDownload StopRequest STATUS_TOO_MANY_REDIRECTS, redirect:" + redirectionCount + " retry:" + retryCount);
        if (retryCount > 0 && redirectionCount == 0) {
            throw new StopRequest(DownloadConsts.Status.STATUS_HTTP_DATA_ERROR,
                    "Too many retries after timeout, retryCount: " + retryCount);
        }
        throw new StopRequest(DownloadConsts.Status.STATUS_TOO_MANY_REDIRECTS,
                "Too many redirects, redirectCount: " + redirectionCount);
    }

    private boolean isRetryableTimeout(StopRequest e) {
        if (e.getFinalStatus() != DownloadConsts.Status.STATUS_HTTP_DATA_ERROR
                || e.getMessage() == null) return false;
        String msg = e.getMessage();
        return msg.contains("SocketTimeoutException") || msg.contains("stalled");
    }

    /**
     * 超时重试前刷新续传状态：根据磁盘文件真实长度同步 mCurrentBytes，
     * 确保下次请求的 Range header 和 FileOutputStream 追加位置一致。
     */
    private void refreshResumingState() throws StopRequest {
        File file = new File(mInfoDelta.savePath);
        if (file.exists()) {
            long fileLength = file.length();
            if (mInfoDelta.mTotalBytes > 0 && fileLength > mInfoDelta.mTotalBytes) {
                LogUtils.e(TAG, "refreshResumingState 文件长度超过 totalBytes，删除重下, fileLength:"
                        + fileLength + ", totalBytes:" + mInfoDelta.mTotalBytes);
                if (!file.delete()) {
                    LogUtils.e(TAG, "refreshResumingState 删除文件失败, savePath:" + mInfoDelta.savePath);
                    throw new StopRequest(DownloadConsts.Status.STATUS_FILE_ERROR,
                            "Failed to delete corrupted download file");
                }
                mInfoDelta.mCurrentBytes = 0;
                mInfo.mCurrentBytes = 0;
                return;
            }
            mInfoDelta.mCurrentBytes = fileLength;
            mInfo.mCurrentBytes = fileLength;
            LogUtils.d(TAG, "refreshResumingState fileLength:" + fileLength + ", savePath:" + mInfoDelta.savePath);
        } else {
            mInfoDelta.mCurrentBytes = 0;
            mInfo.mCurrentBytes = 0;
            LogUtils.d(TAG, "refreshResumingState 文件不存在，重置进度为 0");
        }
    }

    private void checkConnectivity() throws StopRequest {
        int status = mDownloadDelegate.onCurrentNetworkChanged(mInfo);
        if (status != 0) {
            LogUtils.e(TAG, "executeDownload StopRequest checkConnectivity ");
            throw new StopRequest(status, "checkConnectivity");
        }
    }

    private long verifyResuming(String savePath, long currentBytes, long totalBytes) throws StopRequest {
        long bRet = 0;
        if (totalBytes < currentBytes) {
            return 0;
        }
        if (savePath != null) {
            File file = new File(savePath);
            if (LogUtils.isDebug()) {
                LogUtils.e(TAG, "verifyResuming currentBytes:  " + currentBytes + ", totalBytes: " + totalBytes + ", file.exists()， " + file.exists() + " " + savePath);
            }
            if (file.exists()) {
                long fileLength = file.length();
                if (LogUtils.isDebug()) {
                    LogUtils.e(TAG, "verifyResuming currentBytes:  " + currentBytes + ", totalBytes: " + totalBytes + ", fileLength: " + fileLength + " " + savePath);
                }
                if (fileLength == 0) {
                    file.delete();
                } else if (totalBytes > 0 && fileLength > totalBytes) {
                    // 文件长度超过预期总大小，说明之前存在并发追加写入导致文件损坏，删除重新下载
                    LogUtils.e(TAG, "verifyResuming 文件超出预期大小，删除重下: fileLength=" + fileLength + ", totalBytes=" + totalBytes + ", savePath=" + savePath);
                    file.delete();
                } else {
                    if (currentBytes <= fileLength) {
                        FileOutputStream fos = null;
                        try {
                            fos = new FileOutputStream(savePath, true);
                            bRet = fileLength;
                        } catch (FileNotFoundException exc) {
                            throw new StopRequest(DownloadConsts.Status.STATUS_FILE_ERROR, "while opening destination for resuming: ");
                        } finally {
                            FileUtils.closeQuietly(fos);
                        }
                    } else {
                        file.delete();
                    }
                }
            }
        }
        return bRet;
    }

    private void addRequestHeaders(Request.Builder requestBuilder, boolean resuming) {
        requestBuilder.addHeader("User-Agent", GlobalConfig.getDefaultUserAgent());
        requestBuilder.addHeader("Accept-Encoding", "identity");
        requestBuilder.addHeader("Connection", "close");

        if (resuming) {
            if (mInfoDelta.mETag != null) {
                requestBuilder.addHeader("If-Match", mInfoDelta.mETag);
            }
            requestBuilder.addHeader("Range", "bytes=" + mInfo.mCurrentBytes + "-");
            if (LogUtils.isDebug()) {
                LogUtils.e(TAG, "addRequestHeaders range " + mInfoDelta.mCurrentBytes);
            }
        }
    }

    private void parseOkHeaders(Response response) throws StopRequest {

        final String contentDisposition = response.header("Content-Disposition");
        final String contentLocation = response.header("Content-Location");

        mInfoDelta.mMimeType = com.qihoo.utils.MimeUtils.normalizeMimeType(response.header("Content-Type"));
        mInfo.mMimeType = mInfoDelta.mMimeType;


        final String transferEncoding = response.header("Transfer-Encoding");

        long nLen = 0;
        if (transferEncoding == null) {
            nLen = getHeaderFieldLong(response.header("Content-Length"), -1);
            mInfoDelta.mTotalBytes = nLen;
        } else {
            mInfoDelta.mTotalBytes = -1;
        }

        boolean needTFW = mDownloadDelegate.onServerResponse(mInfo, mInfo.mMimeType, nLen);
        if (needTFW) {
            LogUtils.e(TAG, "parseOkHeaders StopRequest httpdownloadthread length is error ");
            throw new StopRequest(DownloadConsts.Status.STATUS_NEED_TFW, "httpdownloadthread length is error");
        }

        mInfo.mTotalBytes = mInfoDelta.mTotalBytes;

        mInfoDelta.mETag = response.header("ETag");
        mInfo.mETag = mInfoDelta.mETag;

        checkConnectivity();
    }

    private void transferData(Response response) throws StopRequest {
        final boolean hasLength = mInfoDelta.mTotalBytes != -1;
        final boolean isConnectionClose = "close".equalsIgnoreCase(response.header("Connection"));
        final boolean isEncodingChunked = "chunked".equalsIgnoreCase(response.header("Transfer-Encoding"));

        final boolean finishKnown = hasLength || isConnectionClose
                || isEncodingChunked;
        if (!finishKnown) {
            LogUtils.e(TAG, "transferData StopRequest STATUS_CANNOT_RESUME ");
            throw new StopRequest(DownloadConsts.Status.STATUS_CANNOT_RESUME,
                    "can't know size of download, giving up");
        }

        InputStream in = null;
        OutputStream out = null;
        ResponseBody responseBody = null;
        try {
            try {
                responseBody = response.body();
                in = responseBody.byteStream();
                mSpeedTracker.start();
            } catch (Exception e) {
                LogUtils.e(TAG, "transferData StopRequest STATUS_HTTP_DATA_ERROR ");
                throw new StopRequest(
                        DownloadConsts.Status.STATUS_HTTP_DATA_ERROR, e);
            }

            try {
                final File file = new File(mInfoDelta.savePath);
                if (!PathUtils.isFilenameValid(mAppContext, file)) {
                    LogUtils.e(TAG, "transferData StopRequest STATUS_FILE_ERROR isFilenameValid");
                    throw new StopRequest(
                            DownloadConsts.Status.STATUS_FILE_ERROR,
                            "inValid file path = " + file.getAbsolutePath());
                }
                // 打开前校验文件实际长度与预期续传点是否一致。
                // 不一致说明暂停/恢复时发生并发写入（旧线程还未退出时新线程已启动），
                // 此时必须重新对齐而不是盲目追加，否则文件会被重复写入超过 totalBytes。
                if (file.exists()) {
                    long actualLength = file.length();
                    if (mInfoDelta.mTotalBytes > 0 && actualLength > mInfoDelta.mTotalBytes) {
                        LogUtils.e(TAG, "transferData 文件长度超过 totalBytes，删除重下: actual="
                                + actualLength + ", total=" + mInfoDelta.mTotalBytes);
                        file.delete();
                        mInfoDelta.mCurrentBytes = 0;
                        mInfo.mCurrentBytes = 0;
                        throw new StopRequest(DownloadConsts.Status.STATUS_HTTP_DATA_ERROR,
                                "file length exceeded totalBytes before write, reset and retry");
                    }
                    if (actualLength != mInfoDelta.mCurrentBytes) {
                        LogUtils.e(TAG, "transferData 文件实际长度与续传点不符，修正: actual="
                                + actualLength + ", expected=" + mInfoDelta.mCurrentBytes);
                        mInfoDelta.mCurrentBytes = actualLength;
                        mInfo.mCurrentBytes = actualLength;
                    }
                }
                out = new FileOutputStream(file, true);
            } catch (IOException e) {
                LogUtils.e(TAG, "transferData StopRequest STATUS_FILE_ERROR IOException");
                throw new StopRequest(DownloadConsts.Status.STATUS_FILE_ERROR,
                        e);
            }

            synchronized (sThreadMap) {
                sThreadMap.put(this, null);
            }
            transferDataImp(in, out);

        } finally {
            synchronized (sThreadMap) {
                sThreadMap.remove(this);
            }
            try {
                if (out != null) {
                    out.flush();
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                FileUtils.closeQuietly(out);
            }
            FileUtils.closeQuietly(in);
            if (responseBody != null) {
                responseBody.close();
            }
        }
    }

    private final static ArrayMap<HttpDownloadThread, StopRequest> sThreadMap = new ArrayMap<>();
    private static ConnectivityManager.NetworkCallback sNetworkCallback;

    static {
        Context context = ContextUtils.getHostAppContext();
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            synchronized (HttpDownloadThread.class) {
                if (sNetworkCallback == null) {
                    sNetworkCallback = new ConnectivityManager.NetworkCallback() {
                        @Override
                        public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
                            super.onCapabilitiesChanged(network, networkCapabilities);
                            Set<HttpDownloadThread> threads;
                            synchronized (sThreadMap) {
                                threads = new HashSet<>(sThreadMap.keySet());
                            }
                            for (HttpDownloadThread t : threads) {
                                try {
                                    if (t != null) {
                                        t.checkConnectivity();
                                    }
                                } catch (StopRequest request) {
                                    synchronized (sThreadMap) {
                                        sThreadMap.put(t, request);
                                    }
                                }
                            }
                        }
                    };
                }
                manager.registerDefaultNetworkCallback(sNetworkCallback);
            }
        }
    }

    // 连续 3 分钟有 read 但无有效进度（每次 read 只拿到极少量数据），判定为服务端假死
    private static final long STALL_TIMEOUT_MS = 3 * 60 * 1000L;
    private static final long STALL_THRESHOLD_BYTES = 1024;

    private void transferDataImp(InputStream in, OutputStream out)
            throws StopRequest {
        final byte buffer[] = new byte[DownloadConsts.BUFFER_SIZE];
        long lastProgressBytes = mInfoDelta.mCurrentBytes;
        long lastProgressTime = System.currentTimeMillis();

        while (true) {
            checkPausedOrCanceled();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                StopRequest stopRequest;
                synchronized (sThreadMap) {
                    stopRequest = sThreadMap.get(this);
                }
                if (stopRequest != null) {
                    throw stopRequest;
                }
            } else {
                checkConnectivity();
            }

            int len;
            try {
                len = in.read(buffer);
            } catch (IOException e) {
                LogUtils.e(TAG, "transferDataImp StopRequest HTTP_PRECON_FAILED ");
                throw new StopRequest(
                        DownloadConsts.Status.STATUS_HTTP_DATA_ERROR,
                        "Failed reading response: " + e, e);
            }

            if (len == -1) {
                break;
            }

            try {
                out.write(buffer, 0, len);
                mSpeedTracker.onBytes(len);
                mInfoDelta.mCurrentBytes += len;
                mInfo.mCurrentBytes = mInfoDelta.mCurrentBytes;

                // 检测服务端假死：有 read 返回但进度几乎不动
                long now = System.currentTimeMillis();
                if (mInfoDelta.mCurrentBytes - lastProgressBytes >= STALL_THRESHOLD_BYTES) {
                    lastProgressBytes = mInfoDelta.mCurrentBytes;
                    lastProgressTime = now;
                } else if (now - lastProgressTime > STALL_TIMEOUT_MS) {
                    // 先判断是否数据已收齐（服务端没发 EOF 也认为完成）
                    if (mInfoDelta.mTotalBytes > 0 && mInfoDelta.mCurrentBytes >= mInfoDelta.mTotalBytes) {
                        LogUtils.e(TAG, "transferDataImp 数据已收齐但服务端未发送 EOF，主动结束, currentBytes:"
                                + mInfoDelta.mCurrentBytes + ", totalBytes:" + mInfoDelta.mTotalBytes);
                        break;
                    }
                    LogUtils.e(TAG, "transferDataImp 下载停滞超时 " + STALL_TIMEOUT_MS + "ms, currentBytes:"
                            + mInfoDelta.mCurrentBytes + ", lastProgressBytes:" + lastProgressBytes);
                    throw new StopRequest(DownloadConsts.Status.STATUS_HTTP_DATA_ERROR,
                            "Download stalled, no progress for " + STALL_TIMEOUT_MS + "ms");
                }

                if (0 != mDownloadDelegate.onProgressChanged(mInfo, mInfo.mCurrentBytes, 0)) {
                    throw new StopRequest(DownloadConsts.Status.STATUS_PAUSED, "");
                }
            } catch (IOException e) {
                handlerAvailableSpaceException(e, mInfoDelta.savePath, len);
                LogUtils.e(TAG, "transferDataImp StopRequest STATUS_FILE_ERROR ");
                throw new StopRequest(DownloadConsts.Status.STATUS_FILE_ERROR, e);
            }
        }

        if (mInfoDelta.mTotalBytes > 0 && mInfoDelta.mCurrentBytes >= 0
                && mInfoDelta.mCurrentBytes != mInfoDelta.mTotalBytes) {
            LogUtils.e(TAG, "transferDataImp StopRequest STATUS_HTTP_DATA_ERROR ");
            throw new StopRequest(DownloadConsts.Status.STATUS_HTTP_DATA_ERROR,
                    "Content length mismatch");
        }
    }

    private void checkPausedOrCanceled() throws StopRequest {
        StopRequest request = null;

        int control = mInfo.syncGetControl();
        if (control == DownloadConsts.Control.CONTROL_PAUSE) {
            mInfo.syncSetStatus(DownloadConsts.Status.STATUS_PAUSING);
            mDownloadDelegate.onProgressChanged(mInfo, mInfo.mCurrentBytes, 0);
            LogUtils.e(TAG, "checkPausedOrCanceled StopRequest STATUS_PAUSED ");
            request = new StopRequest(DownloadConsts.Status.STATUS_PAUSED,
                    "download paused by owner");
        } else if (control == DownloadConsts.Control.CONTROL_CANCEL) {
            mInfo.syncSetStatus(DownloadConsts.Status.STATUS_CANCELING);
            mDownloadDelegate.onProgressChanged(mInfo, mInfo.mCurrentBytes, 0);
            LogUtils.e(TAG, "checkPausedOrCanceled StopRequest STATUS_CANCELED ");
            request = new StopRequest(DownloadConsts.Status.STATUS_CANCELED,
                    "download canceled by owner");
        }

        if (request != null)
            throw request;
    }

    private void handlerAvailableSpaceException(IOException ex,
                                                String savePath, int bytesRead) throws StopRequest {
        if (!SDCardUtils.isSDCardMounted()) {
            LogUtils.e(TAG, "handlerAvailableSpaceException StopRequest STATUS_DEVICE_NOT_FOUND_ERROR ");
            throw new StopRequest(
                    DownloadConsts.Status.STATUS_DEVICE_NOT_FOUND_ERROR,
                    "external media not mounted while writing destination file");
        }

        if (!FileUtils.checkPathWithSize(PathUtils
                .getFilesystemRoot(savePath), bytesRead)) {
            LogUtils.e(TAG, "handlerAvailableSpaceException StopRequest STATUS_INSUFFICIENT_SPACE_ERROR ");
            throw new StopRequest(
                    DownloadConsts.Status.STATUS_INSUFFICIENT_SPACE_ERROR,
                    "insufficient space while writing destination file", ex);
        }
        LogUtils.e(TAG, "handlerAvailableSpaceException StopRequest STATUS_FILE_ERROR ");
        throw new StopRequest(DownloadConsts.Status.STATUS_FILE_ERROR,
                "while writing destination file: " + ex.toString(), ex);
    }

    public class BaseDownloadResource {
        public String downloadUrl;
        public String savePath;
        public int mStatus;
        public long mTotalBytes;
        public long mCurrentBytes;
        public String mETag; // http://blog.csdn.net/t12x3456/article/details/17301897
        public String mMimeType;
        public String mErrorMsg;
        public String mNetCode;

        public BaseDownloadResource(DownloadResInfo info) {
            downloadUrl = info.downloadUrl;
            savePath = info.savePath;
            mStatus = info.mStatus;
            mTotalBytes = info.mTotalBytes;
            mCurrentBytes = info.mCurrentBytes;
            mMimeType = info.mMimeType;
            mETag = info.mETag;
        }
    }

    // 上报下载的平均速度
    private void reportAvgSpeed() {
        DownloadSpeedTracker.Result r = mSpeedTracker.stop();
        if (r == null) return;
        if (r.costSec <= 3) return;

        String total = r.totalMB + "MB";
        String cost = r.costSec + "s";
        String avgSpeed = r.avgSpeedMBps + "MB/s";

        LogUtils.v(TAG, total + "," + cost + "," + avgSpeed);

        // 当前是下载进程，所以发送广播到主进程打点
        Intent intent = new Intent("ACTION_XM_MAIN_APP_PROCESS");
        intent.putExtra("event_key", "download_avg_speed");
        intent.putExtra("total", total);
        intent.putExtra("cost", cost);
        intent.putExtra("avgSpeed", avgSpeed);
        ContextUtils.getHostAppContext().sendBroadcast(intent, "com.magic.gameplf.permission.GXB_INIT");
    }
}
