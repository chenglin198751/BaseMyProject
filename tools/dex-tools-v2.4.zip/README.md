1.把apk转为jar：windows cmd 命令行执行：d2j-dex2jar.bat -f xxx.apk，输出文件为 xxx-dex2jar.jar
2.把dex转为jar：windows cmd 命令行执行：d2j-dex2jar.bat classes.dex，输出文件为 classes-dex2jar.jar


