1、将smali转dex我们需要用到smali.jar这个jar，然后在当前目录输入：java -jar smali.jar test/smali/ -o classes.dex
2、将dex文件转成jar包，我们需要用到dex2jar-2.0里面的 d2j-dex2jar.bat 工具，然后输入如下命令：d2j-dexjar classes.dex